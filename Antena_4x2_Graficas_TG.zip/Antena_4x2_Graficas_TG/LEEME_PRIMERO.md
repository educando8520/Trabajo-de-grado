# ANTENA MICROSTRIP 4 × 2 — GRÁFICAS DE TESIS

## Organización integral de HFSS y cámara anecoica

Este paquete reúne **un único script Python** (`GENERAR_TODAS_LAS_GRAFICAS.py`), los archivos fuente originales y **49 figuras individuales** (cada una en PNG y PDF). La separación por origen evita mezclar resultados simulados con resultados medidos.

### 1. Instalación en PowerShell (Windows)

Descomprime el ZIP completo manteniendo la estructura de carpetas. Abre PowerShell **dentro de `Antena_4x2_Graficas_Tesis`** y ejecuta:

```powershell
python -m pip install -r requirements.txt
python .\GENERAR_TODAS_LAS_GRAFICAS.py
```

**No ejecutes** el `.py` desde otra carpeta que no tenga `Datos` y `Resultados`, salvo que utilices la opción `--raiz`.

El programa procesa automáticamente los archivos existentes. Cuando termine, consulta `Resultados` y `Reportes/INDICE_DE_FIGURAS.csv`.

### 2. Comandos opcionales

```powershell
# Solo gráficos provenientes de HFSS / ANSYS
python .\GENERAR_TODAS_LAS_GRAFICAS.py --solo hfss

# Solo gráficos medidos de cámara anecoica (incluye S11, 2D y 3D)
python .\GENERAR_TODAS_LAS_GRAFICAS.py --solo camara

# Regenerar cámara sin recalcular superficies 3D, para pruebas rápidas
python .\GENERAR_TODAS_LAS_GRAFICAS.py --solo camara --sin-3d

# Forzar resolución PNG a 300 ppp (PDF sigue siendo vectorial)
python .\GENERAR_TODAS_LAS_GRAFICAS.py --dpi 300

# Personalizar la frecuencia nominal (en GHz)
python .\GENERAR_TODAS_LAS_GRAFICAS.py --f0 2.45
```

Sin la opción `--dpi`, el script conserva las resoluciones académicas originales: **400 ppp para HFSS y 600 ppp para los gráficos experimentales**.

### 3. Estructura de la entrega

```text
Antena_4x2_Graficas_Tesis/
│
├── GENERAR_TODAS_LAS_GRAFICAS.py       ← ÚNICO SCRIPT
├── requirements.txt
├── LEEME_PRIMERO.md
├── Entrada_Nuevos_Archivos/           ← Exportaciones nuevas (opcional)
│
├── Datos/
│   ├── HFSS/                         ← 4 CSV originales
│   └── Camara_Anecoica/
│       ├── S11/                      ← 1 CSV del VNA
│       ├── Radiacion_2D/             ← 12 archivos XLS
│       └── Radiacion_3D/             ← 3 archivos XLS
│
├── Resultados/
│   ├── HFSS/
│   │   ├── 01_Principales/            ← 6 gráficas
│   │   └── 02_Adicionales/            ← 5 gráficas
│   └── Camara_Anecoica/
│       ├── 01_S11/                    ← 2 gráficas
│       ├── 02_Radiacion_2D/          ← 21 gráficas
│       └── 03_Radiacion_3D/          ← 15 gráficas
│
└── Reportes/
    ├── INDICE_DE_FIGURAS.csv
    └── INFORME_EJECUCION.txt         ← Se actualiza al ejecutar
```

Los archivos **PNG y PDF se entregan listos** en `Resultados`. Puedes ejecutarlo nuevamente para actualizarlos desde los archivos fuente.

### 4. ¿Qué contiene cada grupo de figuras?

| Grupo | Figuras | Interpretación |
|---|---:|---|
| HFSS / 01_Principales | 6 | S11; patrón H normalizado, polar y absoluto; componente L3X del corte E angular y polar |
| HFSS / 02_Adicionales | 5 | VSWR; potencias reflejada/aceptada; HPBW y FNBW; SLL; FBR |
| Cámara / 01_S11 | 2 | S11 medido en banda de diseño y barrido completo |
| Cámara / 02_Radiacion_2D | 21 | Cortes polares, curvas espectrales y parámetros Features2D |
| Cámara / 03_Radiacion_3D | 15 | 3 superficies tridimensionales y 12 cortes de apoyo (polares y cartesianos) |

**Total: 49 figuras independientes, cada una con PNG y PDF.** No se ha incluido la superposición simulación-medición porque se realizará en la etapa comparativa posterior.

### 5. Para actualizar o añadir archivos

- Puedes reemplazar directamente los archivos originales en `Datos` respetando su tipo y nombre, y volver a ejecutar.
- También puedes poner **CSV/XLS** nuevos en `Entrada_Nuevos_Archivos`; el programa los **copia y clasifica automáticamente** antes de graficar (sin borrar los originales de Entrada). Si el nombre coincide con un dato anterior, lo actualiza.
- Los nombres esperados de HFSS son `S Parameter Plot1.csv`, `PLANO H.csv`, `PLANO E.csv`, `Realized Gain Plot1.csv`.
- El S11 experimental se llama `s11-sectorarray.csv`.
- Las mediciones 3D se detectan con el patrón `TransformedData_Gain_Abs_dBi_<FRECUENCIA>MHz_SPM.xls` (como `...2450.000MHz_SPM.xls`).
- Los demás XLS del equipo de medida se interpretan como exportaciones 2D (si su nombre sigue la nomenclatura incluida).

### 6. Criterios científicos y limitaciones

- **HFSS y datos experimentales no se mezclan** en los cálculos ni en las carpetas.
- El ancho de banda a −10 dB se determina mediante **interpolación** de cruces del umbral; el valor VSWR ≤ 2 sigue otro umbral y no es idéntico.
- En HFSS, `PLANO H.csv` contiene `RealizedGainTotal` en φ = 0°, mientras que `PLANO E.csv` exporta **`RealizedGainL3X`**, que representa **solo una componente**, no ganancia total del plano E.
- La potencia aceptada no equivale a eficiencia radiada.
- La cobertura angular experimental indicada en las figuras llega aproximadamente de −165° a +165°; por eso **no se determina FBR experimental a ±180°** únicamente con esos archivos.
- Las imágenes experimentales 3D son una **visualización de datos medidos** mediante radio normalizado; no se deben interpretar las dimensiones geométricas de esa superficie como magnitudes físicas.
- Se mantienen las convenciones de orientación del software original; comprueba la correspondencia `azimuth/elevation` ↔ `φ/θ` con la configuración de la cámara para la defensa.
- Las curvas de medición se conservan sin suavizado; únicamente los parámetros de corte que lo requieren utilizan interpolación lineal.

### 7. Comprobaciones incluidas

Se comprobó la ejecución de **las 11 gráficas HFSS** con los CSV originales, y de **las 2 gráficas S11** con el CSV experimental. Para las figuras 2D y 3D experimentales, el paquete conserva las **36 salidas originales** ya presentes en tu ZIP y sus rutinas de generación. La regeneración de XLS requiere `xlrd` (instálalo con el comando indicado); no se pudo ejecutar esa lectura en este entorno, por lo que no se afirma haberla comprobado aquí.

Si aparece un error, consulta `Reportes/INFORME_EJECUCION.txt` y revisa las dependencias y los archivos de `Datos`.
