# -*- coding: utf-8 -*-
r"""Comparación selectiva HFSS / cámara anecoica - antena microstrip 4x2.

Colocar este archivo en la carpeta principal Antena_4x2_Graficas_Tesis.
Instalar: python -m pip install numpy pandas matplotlib xlrd
Ejecutar: python .\graficas_comparativas_hfss_camara.py
Solo S11: python .\graficas_comparativas_hfss_camara.py --solo-s11
"""
from pathlib import Path
import argparse
import csv
import io
import re
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import AutoMinorLocator

F0 = 2.450                # GHz
LIMITE_S11 = -10.0        # dB
MEDIDA = '#181818'       # negro, datos reales
HFSS = '#9a3338'         # rojo oscuro, simulación
BASE = Path(__file__).resolve().parent
if not (BASE / 'Datos').is_dir() and (BASE / 'Antena_4x2_Graficas_Tesis' / 'Datos').is_dir():
    BASE /= 'Antena_4x2_Graficas_Tesis'
HF = BASE / 'Datos' / 'HFSS'
CM = BASE / 'Datos' / 'Camara_Anecoica'
SALIDA = BASE / 'Resultados' / 'Comparativas_HFSS_vs_Camara'

plt.rcParams.update({
    'font.family': 'serif', 'font.serif': ['Times New Roman', 'DejaVu Serif'],
    'font.size': 10, 'axes.titlesize': 11, 'axes.labelsize': 10,
    'axes.linewidth': 0.85, 'xtick.direction': 'in', 'ytick.direction': 'in',
    'pdf.fonttype': 42, 'savefig.facecolor': 'white',
})


def guardar(fig, nombre):
    SALIDA.mkdir(parents=True, exist_ok=True)
    fig.savefig(SALIDA / f'{nombre}.png', dpi=350, bbox_inches='tight', pad_inches=0.14)
    fig.savefig(SALIDA / f'{nombre}.pdf', bbox_inches='tight', pad_inches=0.14)
    plt.close(fig)
    print('  ✓', nombre)


def estilo(ax, xlabel, ylabel):
    ax.set_xlabel(xlabel, labelpad=7)
    ax.set_ylabel(ylabel, labelpad=7)
    ax.minorticks_on()
    ax.grid(True, which='major', color='#d2d2d2', lw=0.65)
    ax.grid(True, which='minor', color='#eeeeee', lw=0.35)
    ax.set_axisbelow(True)
    ax.tick_params(which='both', top=True, right=True)


def limpiar(x, y):
    x, y = np.asarray(x, dtype=float), np.asarray(y, dtype=float)
    mask = np.isfinite(x) & np.isfinite(y)
    x, y = x[mask], y[mask]
    orden = np.argsort(x)
    x, y = x[orden], y[orden]
    x, idx = np.unique(x, return_index=True)
    return x, y[idx]


def csv_hfss(nombre):
    ruta = HF / nombre
    df = pd.read_csv(ruta, encoding='utf-8-sig')
    return df


def leer_s11():
    hs = csv_hfss('S Parameter Plot1.csv')
    fh, sh = limpiar(hs.iloc[:, 0], hs.iloc[:, 1])   # GHz; dB
    me = pd.read_csv(CM / 'S11' / 's11-sectorarray.csv', comment='#')
    fm, sm = limpiar(me.iloc[:, 0] / 1e9, me.iloc[:, 1])  # Hz -> GHz
    return (fh, sh), (fm, sm)


def ancho_banda(f, s, umbral=-10.0):
    """Banda contigua S11 <= umbral que contiene 2.45 GHz."""
    if not (f[0] <= F0 <= f[-1]) or np.interp(F0, f, s) > umbral:
        return np.nan, np.nan, np.nan
    zonas = np.where(s <= umbral)[0]
    for z in np.split(zonas, np.where(np.diff(zonas) > 1)[0] + 1):
        if not len(z) or z[0] == 0 or z[-1] == len(s)-1:
            continue
        i, j = z[0], z[-1]
        fl = float(np.interp(umbral, [s[i], s[i-1]], [f[i], f[i-1]]))
        fh = float(np.interp(umbral, [s[j], s[j+1]], [f[j], f[j+1]]))
        if fl <= F0 <= fh:
            return fl, fh, (fh-fl)*1000
    return np.nan, np.nan, np.nan


def leer_xls(nombre):
    try:
        import xlrd
    except ImportError as exc:
        raise SystemExit('Falta xlrd. Instala con: python -m pip install xlrd') from exc
    ruta = CM / 'Radiacion_2D' / nombre
    libro = xlrd.open_workbook(str(ruta), logfile=io.StringIO())
    hoja = libro.sheet_by_index(0)
    return pd.DataFrame([[hoja.cell_value(i, j) for j in range(hoja.ncols)]
                         for i in range(hoja.nrows)])


def serie_frecuencia(tabla, columna):
    """Exportación SPM: primeras 4 filas de cabecera; frecuencia en MHz."""
    f = pd.to_numeric(tabla.iloc[4:, 0], errors='coerce').to_numpy(float) / 1000
    y = pd.to_numeric(tabla.iloc[4:, columna], errors='coerce').to_numpy(float)
    return limpiar(f, y)


def leer_patron_phi0():
    tabla = leer_xls('TransformedData_Gain_Abs_dBi_PhiCut@0.0deg_Polar_SPM.xls')
    freqs = []
    for v in tabla.iloc[0, 1:]:
        if isinstance(v, (int, float)):
            freqs.append(float(v))
        else:
            m = re.search(r'\d+(?:[.,]\d+)?', str(v))
            freqs.append(float(m.group(0).replace(',', '.')) if m else np.nan)
    columnas = np.asarray(freqs, dtype=float)
    if not np.any(np.isfinite(columnas)):
        raise ValueError('No se encontraron frecuencias en el XLS del patrón.')
    idx = int(np.nanargmin(np.abs(columnas-2450)))
    if abs(columnas[idx]-2450) > 0.51:
        raise ValueError('El XLS experimental no tiene el corte a 2450 MHz.')
    t = pd.to_numeric(tabla.iloc[4:, 0], errors='coerce').to_numpy(float)
    g = pd.to_numeric(tabla.iloc[4:, idx+1], errors='coerce').to_numpy(float)
    tm, gm = limpiar(t, g)
    if len(tm) < 30:
        raise ValueError('Patrón experimental con muestras insuficientes.')
    h = csv_hfss('PLANO H.csv')
    columna = next(c for c in h if 'RealizedGainTotal' in c)
    th, gh = limpiar(h['Theta [deg]'], h[columna])
    return (th, gh), (tm, gm)


def metricas_hfss(theta, gain):
    """HPBW con interpolación de cruces a -3 dB; SLL fuera de primeros nulos."""
    k = int(np.argmax(gain))
    peak = float(gain[k]); nivel = peak - 3.0
    izq = k
    while izq > 0 and gain[izq] >= nivel:
        izq -= 1
    der = k
    while der < len(gain)-1 and gain[der] >= nivel:
        der += 1
    t1 = np.interp(nivel, gain[izq:izq+2], theta[izq:izq+2])
    t2 = np.interp(nivel, gain[der-1:der+1][::-1], theta[der-1:der+1][::-1])
    hpbw = float(t2-t1)
    minimos = np.where((gain[1:-1] <= gain[:-2]) & (gain[1:-1] <= gain[2:]))[0] + 1
    anteriores = minimos[minimos < k]
    posteriores = minimos[minimos > k]
    if len(anteriores) and len(posteriores):
        a, b = anteriores[-1], posteriores[0]
        sll = float(max(np.max(gain[:a+1]), np.max(gain[b:])) - peak)
    else:
        sll = np.nan
    return peak, hpbw, sll


def grafica_s11(h, m, resumen):
    fh, sh = h; fm, sm = m
    flh, fhh, bwh = ancho_banda(fh, sh)
    flm, fhm, bwm = ancho_banda(fm, sm)
    fig, ax = plt.subplots(figsize=(8.3, 4.7), constrained_layout=True)
    ax.plot(fm, sm, color=MEDIDA, lw=1.85, label='Cámara anecoica · medición')
    ax.plot(fh, sh, color=HFSS, lw=1.65, ls='--', marker='o', ms=3.0,
            label='HFSS · simulación')
    ax.axhline(LIMITE_S11, color='#666666', ls=':', lw=0.95, label='Criterio −10 dB')
    ax.axvline(F0, color='#777777', ls=':', lw=0.8)
    ax.scatter([F0, F0], [np.interp(F0, fm, sm), np.interp(F0, fh, sh)],
               c=[MEDIDA, HFSS], s=35, zorder=5)
    ax.set_xlim(2.365, 2.53); ax.set_ylim(-27, -1)
    ax.set_title('Comparación del coeficiente de reflexión $S_{11}$\n'
                 'Simulación HFSS y antena 4×2 fabricada', pad=13)
    estilo(ax, 'Frecuencia (GHz)', '$S_{11}$ (dB)')
    ax.text(0.025, 0.06,
            f'BW simulado = {bwh:.2f} MHz\nBW medido = {bwm:.2f} MHz',
            transform=ax.transAxes, va='bottom', fontsize=9,
            bbox={'boxstyle':'round,pad=0.3','fc':'white','ec':'#c7c7c7'})
    ax.legend(fontsize=8.7, loc='upper right', frameon=True)
    guardar(fig, '01_S11_HFSS_vs_Experimental')
    resumen += [
        ('S11 a 2.450 GHz', 'dB', np.interp(F0, fh, sh), np.interp(F0, fm, sm)),
        ('BW -10 dB', 'MHz', bwh, bwm),
        ('Frecuencia resonante', 'GHz', fh[np.argmin(sh)], fm[np.argmin(sm)])
    ]


def grafica_angulos(h, m, resumen):
    th, gh = h; tm, gm = m
    nh = gh - gh.max(); nm = gm - gm.max()
    gh0, hp_h, sll_h = metricas_hfss(th, gh)
    # Se utiliza la misma convención: cada patrón normalizado a su propio máximo.
    fig, ax = plt.subplots(figsize=(8.3, 4.7), constrained_layout=True)
    ax.plot(tm, nm, c=MEDIDA, lw=1.9, label='Medición · $\\phi=0^\\circ$')
    ax.plot(th, nh, c=HFSS, ls='--', lw=1.6, label='HFSS · $\\phi=0^\\circ$')
    ax.axhline(-3, c='#777777', ls=':', lw=0.9, label='Nivel −3 dB')
    ax.axvline(0, c='#999999', ls=':', lw=0.8)
    ax.set_xlim(-100, 100); ax.set_ylim(-37, 2.5)
    estilo(ax, 'Ángulo $\\theta$ (°)', 'Ganancia normalizada (dB)')
    ax.set_title('Patrón de radiación: comparación del plano $\\phi=0^\\circ$\n'
                 'Simulación y medición · 2.450 GHz', pad=13)
    ax.legend(loc='lower right', fontsize=9)
    guardar(fig, '02_Patron_Angular_Phi0_Comparativo')
    fig, ax = plt.subplots(figsize=(6.8, 6.5), subplot_kw={'projection':'polar'})
    fig.subplots_adjust(left=0.09, right=0.91, top=0.82, bottom=0.12)
    ax.set_theta_zero_location('N'); ax.set_theta_direction(-1)
    ang = np.arange(0, 360, 30)
    ax.set_thetagrids(ang, labels=[f'{x if x<=180 else x-360}°' for x in ang])
    ax.plot(np.deg2rad(tm), np.clip(nm, -40, 0)+40, c=MEDIDA, lw=1.9, label='Medición')
    ax.plot(np.deg2rad(th), np.clip(nh, -40, 0)+40, c=HFSS, ls='--', lw=1.5, label='HFSS')
    ax.set_ylim(0, 40); ax.set_yticks([0,10,20,30,40]);
    ax.set_yticklabels(['−40','−30','−20','−10','0'])
    ax.set_rlabel_position(135); ax.grid(color='#cccccc', lw=0.6)
    ax.set_title('Patrón polar comparativo · $\\phi=0^\\circ$\n2.450 GHz · escala normalizada (dB)',
                 fontsize=11, fontweight='bold', pad=24)
    ax.legend(loc='lower center', bbox_to_anchor=(0.5,-0.16), ncol=2, frameon=False)
    guardar(fig, '03_Patron_Polar_Phi0_Comparativo')
    resumen.append(('Ganancia broadside *', 'dBi', gh0, float(np.interp(0, tm, gm))))
    resumen.append(('HPBW plano phi=0', 'grados', hp_h, np.nan))
    resumen.append(('SLL plano phi=0', 'dB relativo', sll_h, np.nan))
    return gh0, hp_h, sll_h


def grafica_metrica(nombre, titulo, f, medida, simulada, unidad, archivo, referencia=None):
    fig, ax = plt.subplots(figsize=(7.8, 4.4), constrained_layout=True)
    ax.plot(f, medida, c=MEDIDA, lw=1.8, label='Medición experimental')
    val_m = float(np.interp(F0, f, medida))
    ax.scatter([F0], [val_m], facecolor='white', edgecolor=MEDIDA, s=55, zorder=5)
    ax.scatter([F0], [simulada], marker='D', color=HFSS, s=55, zorder=6,
               label='HFSS: dato disponible solo a 2.450 GHz')
    ax.axvline(F0, c='#888888', lw=0.85, ls=':')
    if referencia is not None:
        ax.axhline(referencia, c='#777777', lw=0.85, ls=':', label=f'Criterio: {referencia:g} {unidad}')
    ax.annotate(f'Medido: {val_m:.2f} {unidad}', (F0,val_m), xytext=(14,20),
                textcoords='offset points', fontsize=8.4,
                arrowprops={'arrowstyle':'-','lw':0.6,'color':MEDIDA})
    ax.annotate(f'HFSS: {simulada:.2f} {unidad}', (F0,simulada), xytext=(14,-29),
                textcoords='offset points', fontsize=8.4, color=HFSS,
                arrowprops={'arrowstyle':'-','lw':0.6,'color':HFSS})
    ax.set_xlim(max(2.40,f[0]-0.001), min(2.50,f[-1]+0.001))
    ymin = min(float(np.min(medida)), simulada); ymax = max(float(np.max(medida)), simulada)
    intervalo = max(ymax-ymin, 0.8)
    ax.set_ylim(ymin-0.25*intervalo, ymax+0.22*intervalo)
    estilo(ax, 'Frecuencia (GHz)', f'{nombre} ({unidad})')
    ax.set_title(f'Comparación de {titulo}\nAntena 4×2 · simulación y medición', pad=14)
    ax.legend(loc='best', fontsize=8.2)
    guardar(fig, archivo)
    return val_m


def main():
    parser = argparse.ArgumentParser(description='Solo comparativas HFSS vs medición experimental')
    parser.add_argument('--solo-s11', action='store_true', help='Generar solamente S11')
    args = parser.parse_args()
    if not HF.is_dir() or not CM.is_dir():
        raise SystemExit('No encuentro Datos/HFSS y Datos/Camara_Anecoica. '
                         'Coloca el script en la carpeta principal del ZIP organizado.')
    resumen = []
    print('\nGENERANDO GRÁFICAS COMPARATIVAS\nCarpeta:', SALIDA)
    grafica_s11(*leer_s11(), resumen)
    if not args.solo_s11:
        h, m = leer_patron_phi0()
        gh0, hp_h, sll_h = grafica_angulos(h, m, resumen)
        # No se convierte el único dato HFSS a una falsa curva en frecuencia.
        gan = leer_xls('TransformedData_Gain_Abs in dBi @phi 90.0 deg, theta 0.0 deg_SPM.xls')
        fg, vg = serie_frecuencia(gan, 1)
        g_m = grafica_metrica('Ganancia', 'ganancia broadside *', fg, vg, gh0,
                             'dBi', '04_Ganancia_Broadside_Comparativa')
        features = leer_xls('Features2D_TransformedData_Gain_Abs_dBi_PhiCut@0.0deg_Polar_SPM.xls')
        fb, vb = serie_frecuencia(features, 3)
        hp_m = grafica_metrica('HPBW', 'ancho de haz a −3 dB · φ=0°', fb, vb, hp_h,
                              '°', '05_HPBW_Phi0_Comparativa')
        fs, vs = serie_frecuencia(features, 4)
        sll_m = grafica_metrica('SLL', 'lóbulos laterales · φ=0°', fs, vs, sll_h,
                               'dB', '06_SLL_Phi0_Comparativa', referencia=-13)
        resumen = [(n,u,hf, g_m if n=='Ganancia broadside *' else hp_m if n=='HPBW plano phi=0'
                     else sll_m if n=='SLL plano phi=0' else me)
                   for n,u,hf,me in resumen]
    SALIDA.mkdir(parents=True, exist_ok=True)
    with (SALIDA/'RESUMEN_COMPARATIVO.csv').open('w', newline='', encoding='utf-8-sig') as f:
        writer=csv.writer(f, delimiter=';')
        writer.writerow(['Parámetro','Unidad','HFSS','Experimental'])
        for nombre, unidad, v_h, v_m in resumen:
            writer.writerow([nombre, unidad, f'{v_h:.4f}', f'{v_m:.4f}'])
    print('\nListo. Figuras PNG/PDF y RESUMEN_COMPARATIVO.csv guardados en:', SALIDA)
    print('* Ganancia HFSS realizada; ganancia experimental absoluta. No son exactamente la misma magnitud.')
    print('No se comparó φ=90°: HFSS dispone de L3X, no ganancia total para ese corte.')


if __name__ == '__main__':
    main()
