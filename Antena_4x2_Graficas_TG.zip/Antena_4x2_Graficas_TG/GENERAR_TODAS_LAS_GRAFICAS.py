#!/usr/bin/env python3
# -*- coding: utf-8 -*-
r"""
GENERAR_TODAS_LAS_GRAFICAS.py
=======================================
ANTENA MICROSTRIP 4 x 2 - TESIS
ÚNICO SCRIPT PARA ANSYS HFSS Y CÁMARA ANECOICA

Se preservaron las rutinas que ya produjeron las figuras originales.
Cada módulo funcional está encapsulado para evitar colisiones entre funciones
con nombres iguales en los antiguos programas.

Uso (en PowerShell):
    python -m pip install numpy pandas matplotlib scipy xlrd
    python .\GENERAR_TODAS_LAS_GRAFICAS.py

Opciones:
    python .\GENERAR_TODAS_LAS_GRAFICAS.py --solo hfss
    python .\GENERAR_TODAS_LAS_GRAFICAS.py --solo camara
    python .\GENERAR_TODAS_LAS_GRAFICAS.py --dpi 300
    python .\GENERAR_TODAS_LAS_GRAFICAS.py --f0 2.45

El programa no usa datos experimentales para las gráficas de HFSS,
ni archivos simulados para las gráficas de la cámara anecoica.
La componente HFSS L3X en φ=90° no se interpreta como ganancia total.
Las métricas no llevan incertidumbre de medición y la FBR medida no
se estima sin cobertura del ángulo posterior completo.
"""

from __future__ import annotations

import argparse
import csv
import os
import shutil
import sys
import traceback
from pathlib import Path

# Debe establecerse antes de importar pyplot.
os.environ.setdefault("MPLBACKEND", "Agg")


def _verificar_dependencias(solo: str) -> None:
    paquetes = ["numpy", "pandas", "matplotlib"]
    if solo != "hfss":
        paquetes += ["scipy", "xlrd"]
    faltantes = []
    for nombre in paquetes:
        try:
            __import__(nombre)
        except ImportError:
            faltantes.append(nombre)
    if faltantes:
        raise RuntimeError(
            "Faltan librerías: " + ", ".join(faltantes)
            + "\nInstálalas en PowerShell con:\n"
            + "python -m pip install numpy pandas matplotlib scipy xlrd"
        )


def _comprobar_archivos(carpeta: Path, nombres: list[str]) -> None:
    faltantes = [str(carpeta / n) for n in nombres if not (carpeta / n).is_file()]
    if faltantes:
        raise FileNotFoundError("Faltan archivos originales:\n" + "\n".join(faltantes))


def _organizar_nuevos_archivos(raiz: Path) -> None:
    """Clasifica exportaciones nuevas depositadas en Entrada_Nuevos_Archivos.

    Se copian los archivos (no se eliminan los originales). Si una exportación
    tiene el mismo nombre que un dato anterior, la nueva reemplaza a la anterior.
    Solo se reconoce una nomenclatura compatible con los datos recibidos.
    """
    entrada = raiz / "Entrada_Nuevos_Archivos"
    if not entrada.is_dir():
        return
    equivalencias_hfss = {
        "s parameter plot1.csv", "plano h.csv", "plano e.csv", "realized gain plot1.csv"
    }
    movidos = []
    for archivo in sorted(entrada.rglob("*")):
        if not archivo.is_file() or archivo.suffix.lower() not in (".csv", ".xls"):
            continue
        nombre = archivo.name.lower()
        if nombre in equivalencias_hfss:
            destino = raiz / "Datos" / "HFSS" / archivo.name
        elif nombre == "s11-sectorarray.csv":
            destino = raiz / "Datos" / "Camara_Anecoica" / "S11" / archivo.name
        elif archivo.suffix.lower() == ".xls":
            es_3d = (nombre.startswith("transformeddata_gain_abs_dbi_")
                     and "mhz_spm" in nombre)
            tipo = "Radiacion_3D" if es_3d else "Radiacion_2D"
            destino = raiz / "Datos" / "Camara_Anecoica" / tipo / archivo.name
        else:
            continue
        destino.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(archivo, destino)
        movidos.append(f"{archivo.name}  ->  {destino.relative_to(raiz)}")
    if movidos:
        reportes = raiz / "Reportes"
        reportes.mkdir(exist_ok=True)
        (reportes / "DATOS_NUEVOS_ORGANIZADOS.txt").write_text(
            "\n".join(movidos) + "\n", encoding="utf-8")
        print(f"Archivos nuevos clasificados automáticamente: {len(movidos)}")



# ------------------------------------------------------------------
# A. MÓDULOS HFSS - DATOS SIMULADOS
# ------------------------------------------------------------------


# ====================================================================
# B. HFSS - gráficos principales (6 figuras)
# ====================================================================
def _graficar_hfss_principal(ruta_datos: Path, ruta_salida: Path, f0: float, dpi: int | None) -> None:

    # -*- coding: utf-8 -*-
    """
    GRAFICAS HFSS PARA TESIS
    Antena microstrip 4x2 - 2.45 GHz

    Archivos:
        S Parameter Plot1.csv
        Realized Gain Plot1.csv
        PLANO H.csv
        PLANO E.csv

    Salidas:
        6 graficas individuales en PNG y PDF
        RESUMEN_HFSS.txt

    Librerias:
        numpy
        pandas
        matplotlib
    """

    from pathlib import Path

    import numpy as np
    import pandas as pd
    import matplotlib.pyplot as plt

    from matplotlib.ticker import (
        MultipleLocator,
        AutoMinorLocator
    )


    # =========================================================
    # 1. CONFIGURACION
    # =========================================================

    # Por defecto, los CSV estan junto al script.
    CARPETA_DATOS = Path(__file__).resolve().parent

    # Si necesitas una ruta fija, sustituye la linea anterior:
    # CARPETA_DATOS = Path(
    #     r"D:\e50065692\Downloads\SectorArray\SectorArray"
    # )

    SALIDA = CARPETA_DATOS / "figuras_hfss_tesis"
    SALIDA.mkdir(parents=True, exist_ok=True)

    F0 = 2.45
    DPI = 400

    NEGRO = "#141414"
    ROJO = "#94322f"
    AZUL = "#dbe8ef"
    ARENA = "#e8e1cb"

    plt.rcParams.update({
        "font.family": "serif",
        "font.serif": [
            "Times New Roman",
            "STIXGeneral",
            "DejaVu Serif"
        ],
        "mathtext.fontset": "stix",
        "font.size": 11,
        "axes.titlesize": 14,
        "axes.labelsize": 12,
        "xtick.labelsize": 10.5,
        "ytick.labelsize": 10.5,
        "axes.linewidth": 1.05,
        "xtick.direction": "in",
        "ytick.direction": "in",
        "xtick.top": True,
        "ytick.right": True,
        "savefig.facecolor": "white",
        "figure.facecolor": "white",
        "axes.facecolor": "white",
        "pdf.fonttype": 42,
        "ps.fonttype": 42
    })


    # =========================================================
    # 2. FUNCIONES GENERALES
    # =========================================================

    def leer(nombre):

        ruta = CARPETA_DATOS / nombre

        if not ruta.is_file():
            raise FileNotFoundError(
                f"No se encontro el archivo: {ruta}"
            )

        return pd.read_csv(
            ruta,
            encoding="utf-8-sig"
        )


    def datos_angulares(df):

        columna = next(
            (
                c for c in df.columns
                if c.startswith("dB(RealizedGain")
            ),
            None
        )

        if columna is None:
            raise ValueError(
                "No se encontro una columna de ganancia."
            )

        tabla = df[
            ["Theta [deg]", columna]
        ].copy()

        for c in tabla.columns:
            tabla[c] = pd.to_numeric(
                tabla[c],
                errors="coerce"
            )

        tabla = (
            tabla.dropna()
            .sort_values("Theta [deg]")
            .drop_duplicates("Theta [deg]")
        )

        theta = tabla.iloc[:, 0].to_numpy(float)
        ganancia = tabla.iloc[:, 1].to_numpy(float)

        return theta, ganancia, columna


    def formato_cartesiano(ax):

        ax.grid(
            True,
            which="major",
            color="0.84",
            linewidth=0.8
        )

        ax.grid(
            True,
            which="minor",
            color="0.93",
            linewidth=0.45
        )

        ax.set_axisbelow(True)

        ax.xaxis.set_minor_locator(
            AutoMinorLocator(5)
        )

        ax.yaxis.set_minor_locator(
            AutoMinorLocator(2)
        )

        ax.tick_params(
            which="major",
            length=6,
            width=1
        )

        ax.tick_params(
            which="minor",
            length=3,
            width=0.7
        )


    def guardar(fig, nombre):

        fig.savefig(
            SALIDA / f"{nombre}.png",
            dpi=DPI,
            bbox_inches="tight",
            pad_inches=0.15
        )

        fig.savefig(
            SALIDA / f"{nombre}.pdf",
            bbox_inches="tight",
            pad_inches=0.15
        )

        plt.close(fig)

        print(f"Generada: {nombre}")


    def interpolar_cruce(
        x0, y0, x1, y1, nivel
    ):

        if np.isclose(y1, y0):
            return float((x0 + x1) / 2)

        return float(
            x0
            + (nivel - y0)
            * (x1 - x0)
            / (y1 - y0)
        )


    # =========================================================
    # 3. CALCULO DE ANCHO DE BANDA S11
    # =========================================================

    def calcular_bw(freq, s11, limite=-10):

        i = int(np.argmin(s11))

        f_izquierda = None
        f_derecha = None

        for j in range(i - 1, -1, -1):

            if s11[j] > limite >= s11[j + 1]:

                f_izquierda = interpolar_cruce(
                    freq[j],
                    s11[j],
                    freq[j + 1],
                    s11[j + 1],
                    limite
                )

                break

        for j in range(i, len(freq) - 1):

            if s11[j] <= limite < s11[j + 1]:

                f_derecha = interpolar_cruce(
                    freq[j],
                    s11[j],
                    freq[j + 1],
                    s11[j + 1],
                    limite
                )

                break

        return i, f_izquierda, f_derecha


    # =========================================================
    # 4. CALCULO DE HPBW, FNBW, SLL Y FBR
    # =========================================================

    def calcular_hpbw(theta, ganancia, pico):

        umbral = ganancia[pico] - 3

        izquierda = None
        derecha = None

        for j in range(pico - 1, -1, -1):

            if ganancia[j] <= umbral < ganancia[j + 1]:

                izquierda = interpolar_cruce(
                    theta[j],
                    ganancia[j],
                    theta[j + 1],
                    ganancia[j + 1],
                    umbral
                )

                break

        for j in range(pico, len(theta) - 1):

            if ganancia[j] > umbral >= ganancia[j + 1]:

                derecha = interpolar_cruce(
                    theta[j],
                    ganancia[j],
                    theta[j + 1],
                    ganancia[j + 1],
                    umbral
                )

                break

        return izquierda, derecha


    def primer_minimo(ganancia, pico, lado):

        if lado == "izquierda":

            indices = range(
                pico - 1, 0, -1
            )

        else:

            indices = range(
                pico + 1,
                len(ganancia) - 1
            )

        for j in indices:

            if (
                ganancia[j] <= ganancia[j - 1]
                and ganancia[j] <= ganancia[j + 1]
            ):
                return j

        return None


    def calcular_metricas_h(theta, ganancia):

        pico = int(np.argmax(ganancia))

        izq, der = calcular_hpbw(
            theta,
            ganancia,
            pico
        )

        minimo_izq = primer_minimo(
            ganancia, pico, "izquierda"
        )

        minimo_der = primer_minimo(
            ganancia, pico, "derecha"
        )

        if minimo_izq is None or minimo_der is None:
            raise ValueError(
                "No se identificaron los primeros minimos."
            )

        # Los lobulos laterales estan fuera
        # de los dos primeros minimos.

        mascara = (
            (theta < theta[minimo_izq])
            | (theta > theta[minimo_der])
        )

        indices = np.where(mascara)[0]

        secundario = int(
            indices[
                np.argmax(ganancia[indices])
            ]
        )

        ganancia_pico = float(ganancia[pico])

        sll = float(
            ganancia[secundario] - ganancia_pico
        )

        ganancia_espalda = float(
            np.interp(180, theta, ganancia)
        )

        fbr = ganancia_pico - ganancia_espalda

        return {
            "pico": pico,
            "ganancia": ganancia_pico,
            "theta_pico": float(theta[pico]),
            "hpbw_izq": izq,
            "hpbw_der": der,
            "hpbw": der - izq,
            "minimo_izq": minimo_izq,
            "minimo_der": minimo_der,
            "fnbw": float(
                theta[minimo_der]
                - theta[minimo_izq]
            ),
            "secundario": secundario,
            "sll": sll,
            "fbr": fbr,
            "ganancia_espalda": ganancia_espalda
        }


    # =========================================================
    # 5. FORMATO POLAR ACADEMICO
    # =========================================================

    def configurar_polar(
        ax,
        theta,
        valores_normalizados,
        piso=-35
    ):

        # El radio se desplaza a valores positivos.
        # La escala sigue representando dB normalizados.

        radio = (
            np.maximum(valores_normalizados, piso)
            - piso
        )

        ax.set_theta_zero_location("N")
        ax.set_theta_direction(-1)

        ax.plot(
            np.deg2rad(theta),
            radio,
            color=NEGRO,
            linewidth=2,
            zorder=4
        )

        ax.set_rlim(0, -piso)

        marcas = np.arange(
            5,
            -piso + 0.01,
            10
        )

        ax.set_rticks(marcas)

        ax.set_yticklabels(
            [
                f"{valor + piso:.0f}"
                for valor in marcas
            ]
        )

        ax.set_rlabel_position(135)

        angulos = np.arange(0, 360, 30)

        etiquetas = [
            f"{a if a <= 180 else a - 360}°"
            for a in angulos
        ]

        ax.set_thetagrids(
            angulos,
            labels=etiquetas
        )

        ax.grid(
            color="0.74",
            linewidth=0.8
        )

        ax.spines["polar"].set_color("black")
        ax.spines["polar"].set_linewidth(1)

        return radio


    # =========================================================
    # 6. FIGURA 1 - S11 SIMULADO
    # =========================================================

    def graficar_s11():

        df = leer("S Parameter Plot1.csv")

        frecuencia = pd.to_numeric(
            df["Freq [GHz]"],
            errors="coerce"
        ).to_numpy(float)

        s11 = pd.to_numeric(
            df.iloc[:, 1],
            errors="coerce"
        ).to_numpy(float)

        validos = (
            np.isfinite(frecuencia)
            & np.isfinite(s11)
        )

        frecuencia = frecuencia[validos]
        s11 = s11[validos]

        orden = np.argsort(frecuencia)

        frecuencia = frecuencia[orden]
        s11 = s11[orden]

        pico, fl, fh = calcular_bw(
            frecuencia, s11
        )

        fig, ax = plt.subplots(
            figsize=(10.7, 6.1)
        )

        fig.subplots_adjust(
            top=0.84,
            bottom=0.14
        )

        ax.plot(
            frecuencia,
            s11,
            color=NEGRO,
            linewidth=2.2,
            label=r"$S_{11}$ simulado"
        )

        ax.axhline(
            -10,
            color=ROJO,
            linestyle="--",
            linewidth=1.45,
            label=r"Umbral $S_{11}=-10$ dB"
        )

        ax.axvline(
            F0,
            color="0.42",
            linestyle=":",
            linewidth=1.35,
            label=r"$f_0=2.45$ GHz"
        )

        ax.plot(
            frecuencia[pico],
            s11[pico],
            marker="o",
            markersize=8,
            markerfacecolor="white",
            markeredgecolor=NEGRO,
            markeredgewidth=1.7
        )

        ax.annotate(
            (
                rf"$S_{{11,\min}}={s11[pico]:.2f}$ dB"
                + "\n"
                + rf"$f={frecuencia[pico]:.3f}$ GHz"
            ),
            xy=(
                frecuencia[pico],
                s11[pico]
            ),
            xytext=(
                frecuencia[pico] + 0.021,
                s11[pico] - 1.1
            ),
            arrowprops={
                "arrowstyle": "-",
                "linewidth": 1,
                "color": NEGRO
            },
            fontsize=10.5
        )

        if fl is not None and fh is not None:

            bw = (fh - fl) * 1000

            ax.scatter(
                [fl, fh],
                [-10, -10],
                s=45,
                facecolor="white",
                edgecolor=ROJO,
                linewidth=1.6,
                zorder=5
            )

            ax.vlines(
                [fl, fh],
                -10,
                -7.5,
                color="0.30",
                linewidth=0.9
            )

            ax.annotate(
                "",
                xy=(fl, -7.4),
                xytext=(fh, -7.4),
                arrowprops={
                    "arrowstyle": "|-|",
                    "color": NEGRO,
                    "linewidth": 1.1
                }
            )

            ax.text(
                (fl + fh) / 2,
                -6.6,
                f"BW = {bw:.2f} MHz",
                ha="center",
                fontsize=10.5
            )

        ax.set_xlabel("Frecuencia (GHz)")
        ax.set_ylabel(r"$S_{11}$ (dB)")

        ax.set_xlim(
            min(frecuencia),
            max(frecuencia)
        )

        ax.set_ylim(
            min(-26, min(s11) - 2),
            0
        )

        ax.xaxis.set_major_locator(
            MultipleLocator(0.025)
        )

        ax.yaxis.set_major_locator(
            MultipleLocator(5)
        )

        formato_cartesiano(ax)

        ax.legend(
            loc="upper right",
            frameon=True,
            facecolor="white",
            edgecolor="0.70",
            fontsize=9.6
        )

        fig.suptitle(
            "Simulación electromagnética de la antena microstrip 4×2\n"
            r"Coeficiente de reflexión $S_{11}$ — HFSS",
            fontsize=15,
            fontweight="bold"
        )

        guardar(fig, "01_HFSS_S11")

        return frecuencia, s11, pico, fl, fh


    # =========================================================
    # 7. FIGURAS 2, 3 Y 4 - PLANO H
    # =========================================================

    def graficar_plano_h():

        df = leer("PLANO H.csv")

        theta, ganancia, columna = datos_angulares(df)

        if "RealizedGainTotal" not in columna:
            raise ValueError(
                "El archivo PLANO H no contiene ganancia total."
            )

        # Verificacion del archivo adicional.
        ruta_extra = (
            CARPETA_DATOS / "Realized Gain Plot1.csv"
        )

        if ruta_extra.is_file():

            theta2, ganancia2, _ = datos_angulares(
                leer("Realized Gain Plot1.csv")
            )

            coinciden = (
                np.array_equal(theta, theta2)
                and np.allclose(
                    ganancia,
                    ganancia2,
                    atol=1e-9
                )
            )

            print(
                "Coincidencia entre PLANO H y "
                "Realized Gain Plot1:",
                coinciden
            )

        m = calcular_metricas_h(
            theta,
            ganancia
        )

        normalizada = ganancia - m["ganancia"]

        pico = m["pico"]
        sec = m["secundario"]

        ni = m["minimo_izq"]
        nd = m["minimo_der"]

        # -----------------------------------------------------
        # FIGURA 2: PATRON ANGULAR NORMALIZADO
        # -----------------------------------------------------

        fig, ax = plt.subplots(
            figsize=(11.7, 6.3)
        )

        fig.subplots_adjust(
            top=0.84,
            bottom=0.17
        )

        principal = (
            (theta >= theta[ni])
            & (theta <= theta[nd])
        )

        ax.fill_between(
            theta,
            -37,
            normalizada,
            where=principal,
            color=ARENA,
            alpha=0.65
        )

        ax.fill_between(
            theta,
            -37,
            normalizada,
            where=~principal,
            color=AZUL,
            alpha=0.56
        )

        ax.plot(
            theta,
            normalizada,
            color=NEGRO,
            linewidth=2.2,
            zorder=3
        )

        ax.axhline(
            -3,
            color=ROJO,
            linestyle="--",
            linewidth=1.2
        )

        ax.axvline(
            0,
            color="0.45",
            linestyle=":",
            linewidth=1
        )

        puntos = [pico, ni, nd, sec]

        ax.scatter(
            theta[puntos],
            normalizada[puntos],
            s=34,
            color=NEGRO,
            zorder=5
        )

        ax.scatter(
            [m["hpbw_izq"], m["hpbw_der"]],
            [-3, -3],
            s=24,
            color=ROJO,
            zorder=5
        )

        ax.annotate(
            "",
            xy=(m["hpbw_izq"], -4.6),
            xytext=(m["hpbw_der"], -4.6),
            arrowprops={
                "arrowstyle": "<->",
                "color": NEGRO,
                "linewidth": 1.05
            }
        )

        ax.text(
            0,
            -7.2,
            f'HPBW = {m["hpbw"]:.2f}°',
            ha="center",
            fontsize=11.5
        )

        ax.annotate(
            "Lóbulo principal",
            xy=(0, 0),
            xytext=(38, 1.2),
            arrowprops={
                "arrowstyle": "-",
                "color": NEGRO,
                "linewidth": 1
            },
            fontsize=10.8
        )

        ax.annotate(
            (
                "Lóbulo lateral\n"
                f'SLL = {m["sll"]:.2f} dB'
            ),
            xy=(
                theta[sec],
                normalizada[sec]
            ),
            xytext=(-140, -6.6),
            arrowprops={
                "arrowstyle": "-",
                "color": NEGRO,
                "linewidth": 1
            },
            fontsize=10.8
        )

        ax.text(
            0,
            -34.5,
            (
                f'FNBW ≈ {m["fnbw"]:.1f}° '
                "(entre primeros mínimos)"
            ),
            ha="center",
            fontsize=10.6
        )

        ax.set_xlim(-180, 180)
        ax.set_ylim(-37, 3)

        ax.set_xlabel(r"Ángulo $\theta$ (°)")
        ax.set_ylabel("Ganancia normalizada (dB)")

        ax.xaxis.set_major_locator(
            MultipleLocator(30)
        )

        ax.yaxis.set_major_locator(
            MultipleLocator(5)
        )

        formato_cartesiano(ax)

        fig.suptitle(
            "Simulación electromagnética de la antena microstrip 4×2\n"
            "Patrón angular normalizado — plano H "
            "(φ = 0°) · 2.450 GHz",
            fontsize=14.3,
            fontweight="bold"
        )

        fig.text(
            0.5,
            0.035,
            (
                f'Ganancia máxima: {m["ganancia"]:.2f} dBi'
                f'  ·  FBR: {m["fbr"]:.2f} dB'
                " (θ = 0° frente a 180°)"
            ),
            ha="center",
            fontsize=10,
            color="0.32"
        )

        guardar(
            fig,
            "02_HFSS_H_ANGULAR_NORMALIZADO"
        )

        # -----------------------------------------------------
        # FIGURA 3: PATRON POLAR NORMALIZADO
        # -----------------------------------------------------

        fig = plt.figure(
            figsize=(8.5, 8.2)
        )

        ax = fig.add_subplot(
            111,
            projection="polar"
        )

        fig.subplots_adjust(
            top=0.83,
            bottom=0.12,
            left=0.11,
            right=0.88
        )

        radio = configurar_polar(
            ax,
            theta,
            normalizada,
            piso=-35
        )

        ax.fill_between(
            np.deg2rad(theta[ni:nd + 1]),
            0,
            radio[ni:nd + 1],
            color=ARENA,
            alpha=0.42
        )

        ax.plot(
            np.deg2rad(theta),
            radio,
            color=NEGRO,
            linewidth=2,
            zorder=4
        )

        for angulo in [
            m["hpbw_izq"],
            m["hpbw_der"]
        ]:

            ax.plot(
                [np.deg2rad(angulo)] * 2,
                [0, 35],
                color=ROJO,
                linewidth=1.2,
                linestyle="--"
            )

        ax.scatter(
            [np.deg2rad(theta[pico])],
            [radio[pico]],
            color=NEGRO,
            s=35,
            zorder=6
        )

        fig.suptitle(
            "Simulación electromagnética de la antena microstrip 4×2\n"
            "Patrón polar normalizado — plano H "
            "(φ = 0°) · 2.450 GHz",
            fontsize=14,
            fontweight="bold"
        )

        fig.text(
            0.5,
            0.04,
            (
                f'Ganancia máxima: {m["ganancia"]:.2f} dBi'
                f'  ·  HPBW: {m["hpbw"]:.2f}°'
                f'  ·  SLL: {m["sll"]:.2f} dB'
            ),
            ha="center",
            fontsize=10.2
        )

        guardar(
            fig,
            "03_HFSS_H_POLAR_NORMALIZADO"
        )

        # -----------------------------------------------------
        # FIGURA 4: GANANCIA ABSOLUTA
        # -----------------------------------------------------

        fig, ax = plt.subplots(
            figsize=(11.7, 6.3)
        )

        fig.subplots_adjust(
            top=0.84,
            bottom=0.16
        )

        ax.plot(
            theta,
            ganancia,
            color=NEGRO,
            linewidth=2.15
        )

        ax.axvline(
            0,
            color="0.45",
            linestyle=":",
            linewidth=1
        )

        ax.plot(
            theta[pico],
            ganancia[pico],
            "o",
            markersize=6.8,
            markerfacecolor="white",
            markeredgecolor=NEGRO,
            markeredgewidth=1.5
        )

        ax.plot(
            theta[sec],
            ganancia[sec],
            "o",
            markersize=5.5,
            color=NEGRO
        )

        ax.annotate(
            f'Pico: {m["ganancia"]:.2f} dBi',
            xy=(
                theta[pico],
                ganancia[pico]
            ),
            xytext=(30, 13.5),
            arrowprops={
                "arrowstyle": "-",
                "linewidth": 1
            },
            fontsize=11
        )

        ax.annotate(
            f'SLL: {m["sll"]:.2f} dB',
            xy=(
                theta[sec],
                ganancia[sec]
            ),
            xytext=(-145, 5.5),
            arrowprops={
                "arrowstyle": "-",
                "linewidth": 1
            },
            fontsize=10.8
        )

        ax.set_xlim(-180, 180)
        ax.set_ylim(-20, 16)

        ax.set_xlabel(r"Ángulo $\theta$ (°)")
        ax.set_ylabel(
            "Ganancia realizada total (dBi)"
        )

        ax.xaxis.set_major_locator(
            MultipleLocator(30)
        )

        ax.yaxis.set_major_locator(
            MultipleLocator(5)
        )

        formato_cartesiano(ax)

        fig.suptitle(
            "Simulación electromagnética de la antena microstrip 4×2\n"
            "Ganancia realizada total — plano H "
            "(φ = 0°) · 2.450 GHz",
            fontsize=14.3,
            fontweight="bold"
        )

        fig.text(
            0.5,
            0.035,
            (
                "Ganancia a 180°: "
                f'{m["ganancia_espalda"]:.2f} dBi'
                f'  ·  FBR: {m["fbr"]:.2f} dB'
            ),
            ha="center",
            fontsize=10,
            color="0.32"
        )

        guardar(
            fig,
            "04_HFSS_H_GANANCIA_ABSOLUTA"
        )

        return m


    # =========================================================
    # 8. FIGURAS 5 Y 6 - PLANO E
    # =========================================================

    def graficar_plano_e():

        df = leer("PLANO E.csv")

        theta, ganancia, columna = datos_angulares(df)

        es_total = "RealizedGainTotal" in columna

        if es_total:
            componente = "Ganancia realizada total"
        else:
            componente = "Componente de ganancia L3X"

        pico = int(np.argmax(ganancia))

        i0 = int(
            np.argmin(np.abs(theta))
        )

        # -----------------------------------------------------
        # FIGURA 5: REPRESENTACION CARTESIANA
        # -----------------------------------------------------

        fig, ax = plt.subplots(
            figsize=(11.7, 6.3)
        )

        fig.subplots_adjust(
            top=0.84,
            bottom=0.16
        )

        ax.plot(
            theta,
            ganancia,
            color=NEGRO,
            linewidth=2.1
        )

        ax.axvline(
            0,
            color="0.45",
            linestyle=":",
            linewidth=1
        )

        ax.scatter(
            theta[[pico, i0]],
            ganancia[[pico, i0]],
            s=36,
            facecolor="white",
            edgecolor=NEGRO,
            linewidth=1.5,
            zorder=5
        )

        ax.annotate(
            f'Máximo: {ganancia[pico]:.2f} dBi',
            xy=(
                theta[pico],
                ganancia[pico]
            ),
            xytext=(
                55,
                ganancia[pico] - 9
            ),
            arrowprops={
                "arrowstyle": "-",
                "linewidth": 1
            },
            fontsize=10.5
        )

        ax.text(
            0.03,
            0.06,
            (
                "Valor en θ = 0°: "
                f"{ganancia[i0]:.2f} dBi"
            ),
            transform=ax.transAxes,
            fontsize=10.5
        )

        ax.set_xlim(-180, 180)

        ax.set_ylim(
            5 * np.floor((min(ganancia) - 3) / 5),
            5 * np.ceil((max(ganancia) + 3) / 5)
        )

        ax.set_xlabel(r"Ángulo $\theta$ (°)")
        ax.set_ylabel(
            f"{componente} (dBi)"
        )

        ax.xaxis.set_major_locator(
            MultipleLocator(30)
        )

        ax.yaxis.set_major_locator(
            MultipleLocator(5)
        )

        formato_cartesiano(ax)

        fig.suptitle(
            "Simulación electromagnética de la antena microstrip 4×2\n"
            f"{componente} — corte φ = 90° · 2.450 GHz",
            fontsize=14,
            fontweight="bold"
        )

        if not es_total:

            fig.text(
                0.5,
                0.035,
                (
                    "Nota: L3X es una componente de polarización; "
                    "no equivale a la ganancia total del plano E."
                ),
                ha="center",
                fontsize=9.7,
                color="0.32"
            )

        guardar(
            fig,
            (
                "05_HFSS_E_TOTAL_ANGULAR"
                if es_total
                else "05_HFSS_E_L3X_ANGULAR"
            )
        )

        # -----------------------------------------------------
        # FIGURA 6: REPRESENTACION POLAR
        # -----------------------------------------------------

        fig = plt.figure(
            figsize=(8.5, 8.2)
        )

        ax = fig.add_subplot(
            111,
            projection="polar"
        )

        fig.subplots_adjust(
            top=0.83,
            bottom=0.12,
            left=0.11,
            right=0.88
        )

        normalizada = (
            ganancia - ganancia[pico]
        )

        radio = configurar_polar(
            ax,
            theta,
            normalizada,
            piso=-35
        )

        ax.scatter(
            [np.deg2rad(theta[pico])],
            [radio[pico]],
            facecolor="white",
            edgecolor=NEGRO,
            linewidth=1.5,
            s=45,
            zorder=6
        )

        fig.suptitle(
            "Simulación electromagnética de la antena microstrip 4×2\n"
            f"Patrón polar — {componente} "
            "(φ = 90°) · 2.450 GHz",
            fontsize=14,
            fontweight="bold"
        )

        fig.text(
            0.5,
            0.04,
            (
                "Máximo de esta componente: "
                f"{ganancia[pico]:.2f} dBi "
                f"en θ = {theta[pico]:.0f}°"
                "  ·  Escala normalizada (dB)"
            ),
            ha="center",
            fontsize=10
        )

        guardar(
            fig,
            (
                "06_HFSS_E_TOTAL_POLAR"
                if es_total
                else "06_HFSS_E_L3X_POLAR"
            )
        )

        return (
            ganancia[pico],
            theta[pico],
            ganancia[i0],
            columna
        )


    # =========================================================
    # 9. EJECUCION Y REPORTE
    # =========================================================

    def main():

        print("\nGENERANDO GRAFICAS HFSS\n")
        print("Carpeta:", CARPETA_DATOS)

        f, s11, i, fl, fh = graficar_s11()

        metricas_h = graficar_plano_h()

        max_e, theta_e, cero_e, tipo_e = (
            graficar_plano_e()
        )

        resumen = [
            "RESULTADOS HFSS - ANTENA MICROSTRIP 4x2",
            "Frecuencia de diseño: 2.45 GHz",
            "Datos obtenidos de los archivos CSV.",
            "----------------------------------------",
            "",
            f"S11 minimo: {s11[i]:.4f} dB",
            f"Frecuencia del minimo: {f[i]:.5f} GHz",
        ]

        if fl is not None and fh is not None:

            resumen.extend([
                f"fL: {fl:.6f} GHz",
                f"fH: {fh:.6f} GHz",
                f"BW -10 dB: {(fh-fl)*1000:.2f} MHz"
            ])

        resumen.extend([
            "",
            "PLANO H - PHI = 0 GRADOS",
            (
                "Ganancia maxima: "
                f'{metricas_h["ganancia"]:.4f} dBi'
            ),
            (
                "HPBW: "
                f'{metricas_h["hpbw"]:.2f} grados'
            ),
            (
                "FNBW: "
                f'{metricas_h["fnbw"]:.1f} grados'
            ),
            (
                "SLL: "
                f'{metricas_h["sll"]:.2f} dB'
            ),
            (
                "FBR: "
                f'{metricas_h["fbr"]:.2f} dB'
            ),
            "",
            "PLANO E - PHI = 90 GRADOS",
            f"Variable exportada: {tipo_e}",
            f"Maximo: {max_e:.2f} dBi",
            f"Theta del maximo: {theta_e:.0f} grados",
            f"Valor en theta=0: {cero_e:.2f} dBi",
            "",
            "OBSERVACIONES:",
            "BW calculado por interpolacion lineal",
            "de los cruces del umbral -10 dB.",
            "Si PLANO E contiene L3X, no representa",
            "la ganancia realizada total del plano E."
        ])

        texto = "\n".join(resumen)

        archivo = SALIDA / "RESUMEN_HFSS.txt"

        archivo.write_text(
            texto,
            encoding="utf-8"
        )

        print("\n" + texto)

        print(
            "\nFiguras guardadas en:",
            SALIDA
        )

    # Integración: datos HFSS en carpeta exclusiva, sin modificar originales.
    CARPETA_DATOS = ruta_datos
    SALIDA = ruta_salida
    SALIDA.mkdir(parents=True, exist_ok=True)
    F0 = f0
    if dpi is not None: DPI = dpi
    main()




# ====================================================================
# C. HFSS - gráficos derivados (5 figuras)
# ====================================================================
def _graficar_hfss_adicional(ruta_datos: Path, ruta_salida: Path, f0: float, dpi: int | None) -> None:
    # -*- coding: utf-8 -*-
    """
    Graficas adicionales HFSS - Antena microstrip 4x2 - TESIS
    ========================================================
    Entradas reales de HFSS:
      - S Parameter Plot1.csv          (frecuencia, S11 en dB)
      - PLANO H.csv                    (theta, dB(RealizedGainTotal), phi=0)
        o Realized Gain Plot1.csv si no existe PLANO H.csv.

    Salidas: 5 figuras independientes en PNG (400 dpi) y PDF vectorial,
    resumen en .txt y .csv. NO usa datos de camara anecoica, ni sintetiza muestras.

    Requisitos: python -m pip install numpy pandas matplotlib
    Uso:        python graficas_hfss_adicionales.py
    Opcional:    python graficas_hfss_adicionales.py --datos "D:\\MiCarpeta" --f0 2.45

    Nota metrologica: los calculos angulares corresponden a RealizedGainTotal
    (corte phi=0). No se atribuyen a polarizacion copolar sin un CSV de esta.
    """


    import argparse
    import csv
    import sys
    from pathlib import Path

    import matplotlib
    # El backend Agg ya está configurado por el orquestador.
    import matplotlib.pyplot as plt
    import numpy as np
    import pandas as pd
    from matplotlib.ticker import AutoMinorLocator, MultipleLocator


    # ------------------------------- ESTILO ---------------------------------
    DPI = 400
    NEGRO = "#151515"
    GRIS = "#696969"
    ROJO = "#9a3535"  # Curvas de referencia / marcadores tecnicos.
    AZUL = "#1c5467"  # Azul sobrio, en consonancia con estilo de la tesis.
    ARENA = "#e8e3d7"

    plt.rcParams.update({
        "font.family": "serif",
        "font.serif": ["Times New Roman", "STIXGeneral", "DejaVu Serif"],
        "mathtext.fontset": "stix",
        "font.size": 11,
        "axes.titlesize": 13,
        "axes.labelsize": 12,
        "xtick.labelsize": 10,
        "ytick.labelsize": 10,
        "axes.linewidth": 1.05,
        "xtick.direction": "in",
        "ytick.direction": "in",
        "xtick.top": True,
        "ytick.right": True,
        "savefig.facecolor": "white",
        "figure.facecolor": "white",
        "axes.facecolor": "white",
        "pdf.fonttype": 42,
        "ps.fonttype": 42,
    })


    def preparar_ax(ax, xmay=None, ymay=None):
        ax.grid(which="major", color="0.84", lw=0.8)
        ax.grid(which="minor", color="0.93", lw=0.45)
        ax.set_axisbelow(True)
        ax.xaxis.set_minor_locator(AutoMinorLocator(5))
        ax.yaxis.set_minor_locator(AutoMinorLocator(2))
        if xmay is not None:
            ax.xaxis.set_major_locator(MultipleLocator(xmay))
        if ymay is not None:
            ax.yaxis.set_major_locator(MultipleLocator(ymay))
        ax.tick_params(which="major", length=6, width=1.0)
        ax.tick_params(which="minor", length=3, width=0.7)


    def guardar(fig, nombre, salida):
        salida.mkdir(parents=True, exist_ok=True)
        fig.savefig(salida / (nombre + ".png"), dpi=DPI,
                    bbox_inches="tight", pad_inches=0.16)
        fig.savefig(salida / (nombre + ".pdf"),
                    bbox_inches="tight", pad_inches=0.16)
        plt.close(fig)
        print("  [OK]", nombre + ".png / .pdf")


    def titular(fig, subtitulo):
        fig.suptitle("Simulación electromagnética de la antena microstrip 4×2\n"
                     + subtitulo, y=0.975, fontsize=14.3, fontweight="bold")


    def columna(df, terminos, excluir=()):
        for c in df.columns:
            cl = c.lower()
            if any(k in cl for k in terminos) and not any(x in cl for x in excluir):
                return c
        return None


    def a_ghz(valores, nombre_col):
        c = nombre_col.lower()
        if "[ghz]" in c or "(ghz)" in c:
            return valores
        if "[mhz]" in c or "(mhz)" in c:
            return valores / 1e3
        if "[khz]" in c or "(khz)" in c:
            return valores / 1e6
        if "[hz]" in c or "(hz)" in c:
            return valores / 1e9
        raise ValueError("El CSV debe indicar la unidad de frecuencia: Hz, MHz o GHz.")


    def leer_s11(carpeta):
        archivo = carpeta / "S Parameter Plot1.csv"
        if not archivo.exists():
            raise FileNotFoundError("Falta S Parameter Plot1.csv en " + str(carpeta))
        df = pd.read_csv(archivo, encoding="utf-8-sig")
        fcol = columna(df, ["freq", "frecuencia"])
        scol = next((c for c in df.columns if "db(s(" in c.lower()), None)
        if scol is None:
            scol = columna(df, ["s11", "dB(S"], excluir=("freq", "phase", "ang"))
        if fcol is None or scol is None or scol == fcol:
            raise ValueError("S Parameter Plot1.csv: se requieren columnas de frecuencia y S11 en dB.")
        f = a_ghz(pd.to_numeric(df[fcol], errors="coerce").to_numpy(float), fcol)
        s = pd.to_numeric(df[scol], errors="coerce").to_numpy(float)
        ok = np.isfinite(f) & np.isfinite(s)
        f, s = f[ok], s[ok]
        orden = np.argsort(f)
        f, s = f[orden], s[orden]
        if len(f) < 3 or np.any(np.diff(f) <= 0):
            raise ValueError("S11: hay menos de 3 muestras o frecuencias repetidas.")
        if np.any(s >= 0):
            raise ValueError("S11 contiene valores >= 0 dB: VSWR indefinido/no pasivo. Verificar CSV.")
        return f, s


    def leer_h(carpeta, f0):
        archivo = next((carpeta / n for n in ("PLANO H.csv", "Realized Gain Plot1.csv")
                        if (carpeta / n).exists()), None)
        if archivo is None:
            raise FileNotFoundError("Falta PLANO H.csv o Realized Gain Plot1.csv en " + str(carpeta))
        df = pd.read_csv(archivo, encoding="utf-8-sig")
        tcol = columna(df, ["theta"])
        pcol = columna(df, ["phi"])
        fcol = columna(df, ["freq"])
        gcol = next((c for c in df.columns if "db(realizedgaintotal)" in c.lower()), None)
        if not tcol or not gcol:
            raise ValueError(f"{archivo.name} no contiene Theta y dB(RealizedGainTotal). "
                             "No es valido sustituirlo por la componente RealizedGainL3X.")
        if fcol:
            freq = a_ghz(pd.to_numeric(df[fcol], errors="coerce").to_numpy(float), fcol)
            if not np.any(np.isclose(freq, f0, rtol=0, atol=1e-5)):
                raise ValueError(f"{archivo.name}: no contiene muestras a {f0} GHz.")
            df = df.loc[np.isclose(freq, f0, rtol=0, atol=1e-5)].copy()
        if pcol:
            phi = pd.to_numeric(df[pcol], errors="coerce").to_numpy(float)
            if not np.allclose(phi, 0, atol=1e-4):
                raise ValueError(f"{archivo.name}: se esperaba el corte phi=0 grados.")
        t = pd.to_numeric(df[tcol], errors="coerce").to_numpy(float)
        g = pd.to_numeric(df[gcol], errors="coerce").to_numpy(float)
        ok = np.isfinite(t) & np.isfinite(g)
        t, g = t[ok], g[ok]
        orden = np.argsort(t)
        t, g = t[orden], g[orden]
        if len(t) < 20 or np.any(np.diff(t) <= 0):
            raise ValueError("Corte H: muestras angulares insuficientes o duplicadas.")
        if min(t) > -90 or max(t) < 90:
            raise ValueError("Corte H: se requiere al menos [-90, +90] grados para HPBW/SLL.")
        return t, g, archivo.name


    def interpolar_cruce(xa, ya, xb, yb, nivel):
        if ya == yb:
            return float((xa + xb) / 2)
        return float(xa + (nivel - ya) * (xb - xa) / (yb - ya))


    def cruces_umbral_principal(x, y, i_pico, umbral):
        li = ld = None
        for j in range(i_pico - 1, -1, -1):
            if y[j] <= umbral < y[j + 1]:
                li = interpolar_cruce(x[j], y[j], x[j + 1], y[j + 1], umbral)
                break
        for j in range(i_pico, len(y) - 1):
            if y[j] > umbral >= y[j + 1]:
                ld = interpolar_cruce(x[j], y[j], x[j + 1], y[j + 1], umbral)
                break
        return li, ld


    def banda_s11(f, s, umbral, f0):
        if f0 < f[0] or f0 > f[-1]:
            raise ValueError(f"f0={f0} GHz fuera de barrido de S11 ({f[0]} a {f[-1]} GHz).")
        val_f0 = float(np.interp(f0, f, s))
        if val_f0 > umbral:
            return None, None
        # Hallar la seccion contigua con S11 <= umbral que incluye f0.
        tramo = s <= umbral
        candidatos = np.where(tramo)[0]
        i0 = int(candidatos[np.argmin(np.abs(f[candidatos] - f0))])
        izq = i0
        der = i0
        while izq > 0 and tramo[izq - 1]:
            izq -= 1
        while der + 1 < len(f) and tramo[der + 1]:
            der += 1
        fl = None if izq == 0 else interpolar_cruce(f[izq - 1], s[izq - 1], f[izq], s[izq], umbral)
        fh = None if der == len(f) - 1 else interpolar_cruce(f[der], s[der], f[der + 1], s[der + 1], umbral)
        return fl, fh


    def primer_minimo(ganancia, centro, lado):
        if lado == "izq":
            indices = range(centro - 1, 0, -1)
        else:
            indices = range(centro + 1, len(ganancia) - 1)
        for j in indices:
            if ganancia[j] <= ganancia[j - 1] and ganancia[j] <= ganancia[j + 1]:
                return j
        return None


    def metricas_patron(t, g):
        i = int(np.argmax(g))
        pico = float(g[i])
        li, ld = cruces_umbral_principal(t, g, i, pico - 3.0)
        if li is None or ld is None:
            raise ValueError("No aparecen ambos cruces de -3 dB: no se puede calcular HPBW.")
        ni, nd = primer_minimo(g, i, "izq"), primer_minimo(g, i, "der")
        if ni is None or nd is None:
            raise ValueError("No se encontraron ambos primeros minimos: no se calcula FNBW/SLL.")
        # Buscar los maximos secundarios fuera de los primeros minimos.
        outside = (t < t[ni]) | (t > t[nd])
        candidatos = np.flatnonzero(outside)
        if len(candidatos) == 0:
            raise ValueError("No hay muestras fuera del lobulo principal para obtener SLL.")
        j = int(candidatos[np.argmax(g[candidatos])])
        picos_laterales = []
        for k in range(1, len(g) - 1):
            if outside[k] and g[k] >= g[k - 1] and g[k] >= g[k + 1]:
                picos_laterales.append(k)
        if not picos_laterales:
            picos_laterales = [j]
        # FBR: comparacion en direcciones exactas +z (theta=0) y -z (theta=180).
        trasera_ok = (min(t) <= 180 <= max(t))
        frontal_ok = (min(t) <= 0 <= max(t))
        g_frente = float(np.interp(0, t, g)) if frontal_ok else None
        g_espalda = float(np.interp(180, t, g)) if trasera_ok else None
        fbr = g_frente - g_espalda if frontal_ok and trasera_ok else None
        return {
            "i_pico": i, "g_pico": pico, "ang_pico": float(t[i]),
            "hpbw_izq": li, "hpbw_der": ld, "hpbw": ld - li,
            "min_izq_i": ni, "min_der_i": nd,
            "fnbw": float(t[nd] - t[ni]),
            "i_sll": j, "g_lateral": float(g[j]), "ang_lateral": float(t[j]),
            "sll": float(g[j] - pico),
            "picos_laterales": picos_laterales,
            "g_frente": g_frente, "g_espalda": g_espalda, "fbr": fbr,
        }


    # ------------------------------ FIGURAS ---------------------------------

    def fig_vswr(f, s, f0, salida):
        gamma = np.power(10.0, s / 20.0)
        vswr = (1 + gamma) / (1 - gamma)
        s_f0 = float(np.interp(f0, f, s))
        gamma_f0 = 10 ** (s_f0 / 20)
        v_f0 = float((1 + gamma_f0) / (1 - gamma_f0))
        fl2, fh2 = banda_s11(f, s, 20 * np.log10(1 / 3), f0)  # VSWR=2 => |Gamma|=1/3.
        fig, ax = plt.subplots(figsize=(10.9, 6.25))
        fig.subplots_adjust(top=0.82, bottom=0.17)
        ax.plot(f, vswr, color=NEGRO, lw=2.25, label="VSWR simulado")
        ax.axhline(2.0, color=ROJO, ls="--", lw=1.45, label="VSWR = 2")
        ax.axvline(f0, color=GRIS, ls=":", lw=1.25, label=f"{f0:.3f} GHz")
        ax.plot([f0], [v_f0], "o", mfc="white", mec=NEGRO, mew=1.7, ms=8, zorder=5)
        x_span = max(f) - min(f)
        ax.annotate(f"VSWR({f0:.3f} GHz) = {v_f0:.3f}",
                    xy=(f0, v_f0), xytext=(f0 + 0.10 * x_span, 4.05),
                    arrowprops={"arrowstyle": "-", "lw": 0.9, "color": NEGRO}, fontsize=10.5)
        if fl2 is not None and fh2 is not None:
            ax.scatter([fl2, fh2], [2, 2], color=ROJO, s=38, zorder=5)
            ax.text(0.028, 0.935, f"Rango VSWR ≤ 2: {1000*(fh2-fl2):.2f} MHz",
                    transform=ax.transAxes, ha="left", va="top", fontsize=10.5,
                    bbox={"boxstyle": "round,pad=0.27", "fc": "white", "ec": "0.8"})
        ax.set_xlim(f[0], f[-1])
        ax.set_ylim(1, max(4, float(vswr.max()) * 1.09))
        ax.set_xlabel("Frecuencia (GHz)")
        ax.set_ylabel("Relación de onda estacionaria (VSWR)")
        preparar_ax(ax, xmay=0.025)
        ax.legend(loc="upper right", framealpha=1, facecolor="white", edgecolor="0.8", fontsize=9.4)
        titular(fig, "Relación de onda estacionaria (VSWR) — HFSS")
        guardar(fig, "07_HFSS_VSWR", salida)
        return v_f0, fl2, fh2


    def fig_potencia(f, s, f0, salida):
        pref = 100 * np.power(10.0, s / 10.0)
        pacept = 100 - pref
        s_f0 = float(np.interp(f0, f, s))
        p0 = float(100 * 10 ** (s_f0 / 10))
        a0 = float(100 - p0)
        fig, ax = plt.subplots(figsize=(10.9, 6.25))
        fig.subplots_adjust(top=0.82, bottom=0.17)
        ax.plot(f, pref, color=NEGRO, lw=2.1, label="Potencia reflejada")
        ax.plot(f, pacept, color=AZUL, ls="--", lw=2.05, label="Potencia aceptada en el puerto")
        ax.axvline(f0, color=GRIS, ls=":", lw=1.2)
        ax.scatter([f0, f0], [p0, a0], s=52, facecolor="white", edgecolor=NEGRO,
                   linewidth=1.4, zorder=5)
        ax.text(0.02, 0.48,
                f"A {f0:.3f} GHz:\nReflejada: {p0:.2f} %\nAceptada: {a0:.2f} %",
                transform=ax.transAxes, fontsize=10.8, va="center",
                bbox={"boxstyle": "round,pad=0.45", "fc": "white", "ec": "0.78"})
        ax.set(xlim=(f[0], f[-1]), ylim=(0, 103),
               xlabel="Frecuencia (GHz)", ylabel="Potencia relativa a la incidente (%)")
        preparar_ax(ax, xmay=0.025, ymay=20)
        ax.legend(loc="center right", framealpha=1, edgecolor="0.8", fontsize=9.8)
        titular(fig, "Potencia reflejada y aceptada en el puerto — HFSS")
        fig.text(0.5, 0.035,
                 "La potencia aceptada no equivale a la potencia radiada ni a la eficiencia de radiación.",
                 ha="center", fontsize=9.6, color="0.33")
        guardar(fig, "08_HFSS_POTENCIAS_PUERTO", salida)
        return p0, a0


    def fig_hpbw_fnbw(t, g, m, f0, salida):
        gn = g - m["g_pico"]
        fig, ax = plt.subplots(figsize=(11.0, 6.5))
        fig.subplots_adjust(top=0.82, bottom=0.16)
        ventana = (t >= -85) & (t <= 85)
        ax.plot(t[ventana], gn[ventana], color=NEGRO, lw=2.2)
        # Sombreado del lobulo principal definido por primeros minimos.
        ventana_lob = (t >= t[m["min_izq_i"]]) & (t <= t[m["min_der_i"]])
        ax.fill_between(t[ventana_lob], -33, gn[ventana_lob], color=ARENA, alpha=0.56)
        ax.axhline(-3, color=ROJO, ls="--", lw=1.3, label="Nivel de media potencia (−3 dB)")
        ax.axvline(0, color="0.65", ls=":", lw=1.0)
        cruces = [m["hpbw_izq"], m["hpbw_der"]]
        ax.scatter(cruces, [-3, -3], facecolor="white", edgecolor=ROJO,
                   s=65, linewidth=1.7, zorder=5)
        ax.annotate("", xy=(cruces[0], -6.2), xytext=(cruces[1], -6.2),
                    arrowprops={"arrowstyle": "<->", "color": ROJO, "lw": 1.15})
        ax.text(0, -8.6, f"HPBW = {m['hpbw']:.2f}°", ha="center", fontsize=10.7, color=ROJO)
        tmin = [float(t[m["min_izq_i"]]), float(t[m["min_der_i"]])]
        gmin = [float(gn[m["min_izq_i"]]), float(gn[m["min_der_i"]])]
        ax.scatter(tmin, gmin, facecolor="white", edgecolor=NEGRO, s=63, linewidth=1.5, zorder=5)
        ax.annotate("", xy=(tmin[0], -33.5), xytext=(tmin[1], -33.5),
                    arrowprops={"arrowstyle": "<->", "color": NEGRO, "lw": 1.1})
        ax.text(0, -36.3, f"FNBW ≈ {m['fnbw']:.1f}°", ha="center", fontsize=10.7)
        ax.set(xlim=(-85, 85), ylim=(-39, 4),
               xlabel=r"Ángulo $\theta$ (°)", ylabel="Ganancia realizada total normalizada (dB)")
        preparar_ax(ax, xmay=10, ymay=5)
        ax.legend(loc="upper right", framealpha=1, edgecolor="0.8", fontsize=9.5)
        titular(fig, f"HPBW y FNBW — corte φ = 0° · {f0:.3f} GHz")
        fig.text(0.5, 0.034, "HPBW por cruces interpolados; FNBW entre primeros mínimos muestreados.",
                 ha="center", fontsize=9.6, color="0.33")
        guardar(fig, "09_HFSS_H_HPBW_FNBW", salida)


    def fig_sll(t, g, m, f0, salida):
        gn = g - m["g_pico"]
        i, j = m["i_pico"], m["i_sll"]
        fig, ax = plt.subplots(figsize=(11.4, 6.4))
        fig.subplots_adjust(top=0.83, bottom=0.17)
        ax.plot(t, gn, color=NEGRO, lw=2.0)
        ax.axhline(gn[j], color=ROJO, ls="--", lw=1.2,
                   label=f"Nivel del mayor lóbulo secundario ({m['sll']:.2f} dB)")
        ax.axhline(0, color="0.62", ls=":", lw=1)
        ax.scatter([t[i]], [0], marker="o", s=70, facecolor="white", edgecolor=NEGRO,
                   linewidth=1.7, zorder=6)
        for k in m["picos_laterales"]:
            if gn[k] >= -30:
                ax.scatter([t[k]], [gn[k]], s=23, color=AZUL, zorder=5)
        ax.scatter([t[j]], [gn[j]], s=80, facecolor="white", edgecolor=ROJO,
                   linewidth=1.9, zorder=6)
        ax.annotate(f"Mayor lóbulo secundario\nθ = {t[j]:.1f}°\nSLL = {m['sll']:.2f} dB",
                    xy=(t[j], gn[j]), xytext=(20, -9.4),
                    arrowprops={"arrowstyle": "-", "color": ROJO, "lw": 1.05},
                    fontsize=10.5, ha="left", color=NEGRO)
        ax.text(0, 1.5, f"Lóbulo principal: {m['g_pico']:.2f} dBi", ha="center", fontsize=10.5)
        ax.axvline(t[m["min_izq_i"]], color="0.7", ls=":", lw=0.9)
        ax.axvline(t[m["min_der_i"]], color="0.7", ls=":", lw=0.9)
        ax.set(xlim=(-180, 180), ylim=(min(-40, float(np.min(gn)) - 2), 5),
               xlabel=r"Ángulo $\theta$ (°)", ylabel="Ganancia realizada total normalizada (dB)")
        preparar_ax(ax, xmay=30, ymay=10)
        ax.legend(loc="lower right", edgecolor="0.8", facecolor="white", fontsize=9.3)
        titular(fig, f"Nivel de lóbulos secundarios (SLL) — corte φ = 0° · {f0:.3f} GHz")
        fig.text(0.5, 0.036,
                 r"$SLL = G_{\mathrm{lateral,max}} - G_{\mathrm{principal,max}}$ (dB); ganancia realizada total.",
                 ha="center", fontsize=10.0, color="0.33")
        guardar(fig, "10_HFSS_H_SLL", salida)


    def fig_fbr(t, g, m, f0, salida):
        if m["fbr"] is None:
            print("  [AVISO] FBR no se calcula: el corte no contiene theta=0 y theta=180.")
            return
        fig, ax = plt.subplots(figsize=(10.8, 6.3))
        fig.subplots_adjust(top=0.82, bottom=0.16)
        ax.plot(t, g, color=NEGRO, lw=2.1, label="Ganancia realizada total")
        a, b = m["g_frente"], m["g_espalda"]
        ax.scatter([0, 180], [a, b], s=82, facecolor="white", edgecolor=ROJO,
                   lw=2.0, zorder=6)
        ax.axvline(0, color=GRIS, ls=":", lw=1)
        ax.axvline(180, color=GRIS, ls=":", lw=1)
        ax.annotate(f"Frente (+z)\n{a:.2f} dBi", xy=(0, a), xytext=(-105, a-6.8),
                    arrowprops={"arrowstyle": "-", "lw": 1.0, "color": NEGRO},
                    fontsize=10.4, ha="center")
        ax.annotate(f"Espalda (−z)\n{b:.2f} dBi", xy=(180, b), xytext=(97, b+7),
                    arrowprops={"arrowstyle": "-", "lw": 1.0, "color": NEGRO},
                    fontsize=10.4, ha="center")
        ax.text(0.76, 0.87, f"FBR = {m['fbr']:.2f} dB", transform=ax.transAxes,
                fontsize=12.0, fontweight="bold", ha="center",
                bbox={"boxstyle": "round,pad=0.45", "fc": "white", "ec": "0.7"})
        ax.set(xlim=(-180, 185),
               ylim=(min(float(g.min()) - 3, -20), max(float(g.max()) + 3, 17)),
               xlabel=r"Ángulo $\theta$ (°)", ylabel="Ganancia realizada total (dBi)")
        preparar_ax(ax, xmay=30, ymay=5)
        titular(fig, f"Relación frente–espalda (FBR) — corte φ = 0° · {f0:.3f} GHz")
        fig.text(0.5, 0.034,
                 r"$FBR = G(\theta=0^\circ)-G(\theta=180^\circ)$; comparación en direcciones exactas.",
                 ha="center", fontsize=9.9, color="0.33")
        guardar(fig, "11_HFSS_H_FBR", salida)


    def num_str(x, fmt=".4f"):
        return "No disponible" if x is None else format(float(x), fmt)


    def main():
        parser = argparse.ArgumentParser(
            description="Graficas adicionales HFSS desde CSV reales; sin datos experimentales.")
        parser.add_argument("--datos", type=Path, default=Path(__file__).resolve().parent,
                            help="Carpeta que contiene S Parameter Plot1.csv y PLANO H.csv.")
        parser.add_argument("--salida", type=Path, default=None,
                            help="Carpeta de salida; por defecto figuras_hfss_adicionales.")
        parser.add_argument("--f0", type=float, default=2.45,
                            help="Frecuencia objetivo en GHz (por defecto 2.45).")
        args = parser.parse_args()
        datos = args.datos.resolve()
        salida = args.salida.resolve() if args.salida else datos / "figuras_hfss_adicionales"
        print("\n=== GRAFICAS ADICIONALES HFSS - ANTENA 4x2 ===")
        print("Datos:", datos)
        print("Salida:", salida)
        f, s = leer_s11(datos)
        t, g, origen_h = leer_h(datos, args.f0)
        print("Fuentes: S Parameter Plot1.csv y", origen_h)
        m = metricas_patron(t, g)
        v0, fl_vswr, fh_vswr = fig_vswr(f, s, args.f0, salida)
        pref, pacept = fig_potencia(f, s, args.f0, salida)
        fig_hpbw_fnbw(t, g, m, args.f0, salida)
        fig_sll(t, g, m, args.f0, salida)
        fig_fbr(t, g, m, args.f0, salida)
        fl10, fh10 = banda_s11(f, s, -10, args.f0)
        s0 = float(np.interp(args.f0, f, s))
        tabla = {
            "f_objetivo_GHz": args.f0,
            "S11_en_f0_dB": s0,
            "fL_S11_menos10_GHz": fl10,
            "fH_S11_menos10_GHz": fh10,
            "BW_S11_menos10_MHz": 1000 * (fh10 - fl10) if fl10 is not None and fh10 is not None else None,
            "VSWR_en_f0": v0,
            "fL_VSWR2_GHz": fl_vswr,
            "fH_VSWR2_GHz": fh_vswr,
            "BW_VSWR2_MHz": 1000 * (fh_vswr - fl_vswr) if fl_vswr is not None and fh_vswr is not None else None,
            "Potencia_reflejada_f0_pct": pref,
            "Potencia_aceptada_f0_pct": pacept,
            "Phi_deg": 0.0,
            "Ganancia_pico_dBi": m["g_pico"],
            "Theta_pico_deg": m["ang_pico"],
            "HPBW_deg": m["hpbw"],
            "FNBW_deg_aprox": m["fnbw"],
            "Theta_primer_min_izq_deg": float(t[m["min_izq_i"]]),
            "Theta_primer_min_der_deg": float(t[m["min_der_i"]]),
            "Ganancia_lateral_max_dBi": m["g_lateral"],
            "Theta_lateral_max_deg": m["ang_lateral"],
            "SLL_dB": m["sll"],
            "Ganancia_frontal_0deg_dBi": m["g_frente"],
            "Ganancia_trasera_180deg_dBi": m["g_espalda"],
            "FBR_dB": m["fbr"],
        }
        salida.mkdir(parents=True, exist_ok=True)
        with (salida / "RESUMEN_METRICAS_ADICIONALES.csv").open("w", newline="", encoding="utf-8-sig") as arch:
            escritor = csv.DictWriter(arch, fieldnames=list(tabla))
            escritor.writeheader()
            escritor.writerow(tabla)
        notas = [
            "RESULTADOS ADICIONALES HFSS - ANTENA MICROSTRIP 4x2",
            "Fuente S11: S Parameter Plot1.csv",
            "Fuente de patron: " + origen_h + " (dB(RealizedGainTotal), phi=0)",
            "No se usan datos experimentales ni se interpolan curvas visualmente.",
            "", "RESULTADOS EN FRECUENCIA",
            f"Frecuencia objetivo: {args.f0:.4f} GHz",
            f"S11(f0): {s0:.4f} dB",
            f"Banda S11 <= -10 dB: {num_str(fl10, '.6f')} a {num_str(fh10, '.6f')} GHz",
            f"BW S11 <= -10 dB: {num_str(tabla['BW_S11_menos10_MHz'], '.3f')} MHz",
            f"VSWR(f0): {v0:.4f}",
            f"Banda VSWR <= 2: {num_str(fl_vswr, '.6f')} a {num_str(fh_vswr, '.6f')} GHz",
            f"BW VSWR <= 2: {num_str(tabla['BW_VSWR2_MHz'], '.3f')} MHz",
            f"Potencia reflejada(f0): {pref:.4f} %",
            f"Potencia aceptada(f0): {pacept:.4f} %",
            "", "RESULTADOS ANGULARES: PHI = 0 DEG, F = %.4f GHz" % args.f0,
            f"Ganancia principal: {m['g_pico']:.4f} dBi en theta={m['ang_pico']:.2f} deg",
            f"HPBW: {m['hpbw']:.4f} deg (cruces -3 dB interpolados)",
            f"FNBW: {m['fnbw']:.2f} deg (entre primeros minimos muestreados)",
            f"Maximo lobulo secundario: {m['g_lateral']:.4f} dBi, theta={m['ang_lateral']:.2f} deg",
            f"SLL: {m['sll']:.4f} dB (maximo lateral menos maximo principal)",
            f"Ganancia frontal theta=0: {num_str(m['g_frente'])} dBi",
            f"Ganancia posterior theta=180: {num_str(m['g_espalda'])} dBi",
            f"FBR 0 vs 180: {num_str(m['fbr'])} dB",
            "", "ADVERTENCIAS DE INTERPRETACION",
            "1. S11 <= -10 dB no equivale exactamente a VSWR <= 2 (VSWR=2: S11=-9.5424 dB).",
            "2. Aceptada = incidente - reflejada en puerto; NO es eficiencia radiada.",
            "3. SLL y FBR corresponden a GANANCIA REALIZADA TOTAL del plano phi=0;",
            "   no implican una medicion copolar sin datos de esa componente.",
            "4. El FNBW es aproximado por paso angular del CSV; HPBW interpola cruces.",
            "5. PLANO E.csv disponible posee L3X: no es ganancia total, por eso",
            "   no se generan HPBW ni FBR del plano E con ese archivo.",
            "6. Los calculos no incluyen incertidumbre ni variacion por malla de HFSS.",
        ]
        (salida / "RESUMEN_METRICAS_ADICIONALES.txt").write_text("\n".join(notas) + "\n", encoding="utf-8")
        print("\n" + "\n".join(notas))
        print("\nFIGURAS GENERADAS EN:", salida)

    # El programa original ya permite indicar datos/salida por argumentos.
    if dpi is not None: DPI = dpi
    _argv_antiguo = sys.argv[:]
    try:
        sys.argv = [_argv_antiguo[0], "--datos", str(ruta_datos), "--salida", str(ruta_salida), "--f0", str(f0)]
        main()
    finally:
        sys.argv = _argv_antiguo




# ====================================================================
# D. Cámara anecoica - S11 experimental
# ====================================================================
def _graficar_s11_experimental(ruta_datos: Path, ruta_salida: Path, f0: float, dpi: int | None) -> None:

    # -*- coding: utf-8 -*-
    """
    S11 EXPERIMENTAL - FIGURAS ACADEMICAS
    Antena microstrip 4x2 | Trabajo de grado

    Genera:
        1. S11 en la banda de 2.45 GHz
        2. S11 en el barrido completo

    Exporta PDF vectorial y PNG de 600 dpi.
    """

    from pathlib import Path
    import sys

    import numpy as np
    import pandas as pd
    import matplotlib.pyplot as plt

    from matplotlib.ticker import AutoMinorLocator


    # ============================================================
    # 1. CONFIGURACION
    # ============================================================

    # None abre el explorador de archivos de Windows.
    # Para utilizar siempre el mismo CSV, escribe su ruta:
    #
    # ARCHIVO = r'D:\e50065692\Downloads\SectorArray\SectorArray\s11-sectorarray.csv'

    ARCHIVO = None

    F0_GHZ = 2.45
    UMBRAL_DB = -10.0

    # Limites de la grafica ampliada
    ZOOM_GHZ = (2.37, 2.53)

    MOSTRAR_FIGURAS = True


    # ============================================================
    # 2. ESTILO ACADEMICO
    # ============================================================

    plt.rcParams.update({

        'font.family': 'serif',

        'font.serif': [
            'Times New Roman',
            'DejaVu Serif',
            'Liberation Serif'
        ],

        'mathtext.fontset': 'stix',

        'font.size': 10,
        'axes.labelsize': 11,

        'axes.linewidth': 0.85,

        'xtick.direction': 'in',
        'ytick.direction': 'in',

        'xtick.major.size': 5,
        'ytick.major.size': 5,

        'xtick.minor.size': 2.5,
        'ytick.minor.size': 2.5,

        'pdf.fonttype': 42,
        'ps.fonttype': 42,

        'figure.facecolor': 'white',
        'savefig.facecolor': 'white'

    })


    # ============================================================
    # 3. SELECCION DEL ARCHIVO
    # ============================================================

    def elegir_archivo():

        # Permite pasar el CSV por la terminal
        if len(sys.argv) > 1:
            return Path(sys.argv[1])

        # Permite configurar una ruta fija
        if ARCHIVO:
            return Path(ARCHIVO)

        # Seleccion mediante ventana
        from tkinter import Tk, filedialog

        raiz = Tk()
        raiz.withdraw()
        raiz.attributes('-topmost', True)

        nombre = filedialog.askopenfilename(

            title='Seleccione el CSV de S11 medido',

            filetypes=[
                ('Archivos CSV', '*.csv'),
                ('Archivos TXT', '*.txt'),
                ('Todos los archivos', '*.*')
            ]

        )

        raiz.destroy()

        if not nombre:
            sys.exit('No se selecciono ningun archivo.')

        return Path(nombre)


    # ============================================================
    # 4. LECTURA DEL CSV
    # ============================================================

    def leer_csv(ruta):

        tabla = pd.read_csv(
            ruta,
            comment='#',
            sep=None,
            engine='python',
            encoding='utf-8-sig'
        )

        columnas = [
            str(c).strip().lower()
            for c in tabla.columns
        ]

        # Identificar frecuencia
        c_f = next(
            (
                i for i, c in enumerate(columnas)
                if 'freq' in c or 'frecuencia' in c
            ),
            None
        )

        # Identificar magnitud S11 en decibelios
        c_s = next(
            (
                i for i, c in enumerate(columnas)
                if 'db' in c
                and ('s11' in c or 's(1,1)' in c)
            ),
            None
        )

        if c_f is None or c_s is None:

            raise ValueError(
                'No se identificaron las columnas de '
                'frecuencia y S11 en dB.\n'
                f'Columnas encontradas: {list(tabla.columns)}'
            )

        f = pd.to_numeric(
            tabla.iloc[:, c_f],
            errors='coerce'
        ).to_numpy(dtype=float)

        s = pd.to_numeric(
            tabla.iloc[:, c_s],
            errors='coerce'
        ).to_numpy(dtype=float)

        validos = np.isfinite(f) & np.isfinite(s)

        f = f[validos]
        s = s[validos]

        # Conversion de frecuencia a GHz
        cabecera = columnas[c_f]

        if 'ghz' in cabecera:
            pass

        elif 'mhz' in cabecera:
            f = f / 1e3

        elif 'khz' in cabecera:
            f = f / 1e6

        elif 'hz' in cabecera:
            f = f / 1e9

        else:
            raise ValueError(
                'El CSV no indica la unidad de frecuencia. '
                'Se requiere Hz, MHz o GHz.'
            )

        # Organizacion ascendente
        orden = np.argsort(f)

        f = f[orden]
        s = s[orden]

        # Eliminar frecuencias duplicadas
        f, indices = np.unique(
            f,
            return_index=True
        )

        s = s[indices]

        if len(f) < 5:

            raise ValueError(
                'El CSV no contiene suficientes muestras.'
            )

        if not (f[0] <= F0_GHZ <= f[-1]):

            raise ValueError(
                'La frecuencia objetivo esta fuera del barrido.'
            )

        return f, s


    # ============================================================
    # 5. INTERPOLACION
    # ============================================================

    def interpolar_cruce(x1, y1, x2, y2, nivel):

        return float(
            x1
            + (nivel - y1) * (x2 - x1) / (y2 - y1)
        )


    # ============================================================
    # 6. ANALISIS DEL S11
    # ============================================================

    def analizar(f, s):

        # S11 interpolado en la frecuencia de diseño
        s_f0 = float(
            np.interp(F0_GHZ, f, s)
        )

        # Identificar intervalos por debajo de -10 dB
        debajo = s <= UMBRAL_DB

        cambios = np.diff(
            np.r_[False, debajo, False].astype(int)
        )

        inicios = np.flatnonzero(cambios == 1)
        finales = np.flatnonzero(cambios == -1) - 1

        banda = None
        zona = None

        # Seleccionar la banda que contiene 2.45 GHz
        for a, b in zip(inicios, finales):

            if a > 0:

                fL = interpolar_cruce(
                    f[a-1], s[a-1],
                    f[a], s[a],
                    UMBRAL_DB
                )

            else:
                fL = None

            if b < len(f)-1:

                fH = interpolar_cruce(
                    f[b], s[b],
                    f[b+1], s[b+1],
                    UMBRAL_DB
                )

            else:
                fH = None

            if fL is not None and fH is not None:

                if fL <= F0_GHZ <= fH:

                    BW = (fH - fL) * 1000

                    banda = (fL, fH, BW)
                    zona = slice(a, b+1)

                    break

        # Buscar el minimo experimental
        if zona is not None:

            indice = (
                zona.start + np.argmin(s[zona])
            )

        else:

            indices = np.flatnonzero(
                np.abs(f - F0_GHZ) <= 0.12
            )

            if not len(indices):
                indices = np.arange(len(f))

            indice = int(
                indices[np.argmin(s[indices])]
            )

        return {

            'fr': float(f[indice]),
            'smin': float(s[indice]),
            'sf0': s_f0,

            'banda': banda,

            'paso_mhz': float(
                np.median(np.diff(f)) * 1000
            )

        }


    # ============================================================
    # 7. FORMATO DE LOS EJES
    # ============================================================

    def aplicar_estilo(ax, xmin, xmax):

        ax.set_xlim(xmin, xmax)

        ax.set_xlabel(
            'Frecuencia (GHz)',
            labelpad=7
        )

        ax.set_ylabel(
            r'$S_{11}$ (dB)',
            labelpad=8
        )

        # Graduaciones secundarias
        ax.xaxis.set_minor_locator(
            AutoMinorLocator(5)
        )

        ax.yaxis.set_minor_locator(
            AutoMinorLocator(2)
        )

        # Graduaciones en los cuatro lados
        ax.tick_params(
            which='both',
            top=True,
            right=True
        )

        # Cuadricula academica discreta
        ax.grid(
            which='major',
            color='#d8d8d8',
            linewidth=0.50
        )

        ax.grid(
            which='minor',
            color='#eeeeee',
            linewidth=0.35
        )

        ax.set_axisbelow(True)


    # ============================================================
    # 8. EXPORTACION
    # ============================================================

    def exportar(fig, carpeta, nombre):

        # PDF vectorial
        fig.savefig(
            carpeta / f'{nombre}.pdf',
            bbox_inches='tight',
            pad_inches=0.12
        )

        # PNG de alta resolucion
        fig.savefig(
            carpeta / f'{nombre}.png',
            dpi=DPI_EXPORT,
            bbox_inches='tight',
            pad_inches=0.12
        )


    # ============================================================
    # 9. FIGURA PRINCIPAL - DETALLE 2.45 GHz
    # ============================================================

    def figura_detalle(f, s, r, carpeta):

        fig, ax = plt.subplots(
            figsize=(7.0, 4.5),
            constrained_layout=True
        )

        aplicar_estilo(
            ax,
            ZOOM_GHZ[0],
            ZOOM_GHZ[1]
        )

        ax.set_title(
            'Caracterización experimental de la antena 4×2 fabricada\n'
            r'Parámetro $S_{11}$ medido en la banda de 2.45 GHz',
            fontsize=11,
            fontweight='bold',
            fontfamily='serif',
            pad=16,
            loc='center'
        )

        # Limites verticales
        rango = (
            (f >= ZOOM_GHZ[0])
            & (f <= ZOOM_GHZ[1])
        )

        ymin = min(
            -27.0,
            float(np.floor(s[rango].min()/5)*5)
        )

        ax.set_ylim(ymin, 0)

        # Curva experimental principal
        ax.plot(
            f, s,
            color='black',
            linewidth=1.65,
            label=r'$S_{11}$ medido',
            zorder=4
        )

        # Criterio de adaptacion
        ax.axhline(
            UMBRAL_DB,
            color='#9b3838',
            linestyle='--',
            linewidth=1.05,
            label=r'Límite $S_{11}=-10$ dB',
            zorder=2
        )

        # Frecuencia objetivo
        ax.axvline(
            F0_GHZ,
            color='#555555',
            linestyle=':',
            linewidth=0.95,
            label=r'$f_0=2.45$ GHz',
            zorder=2
        )

        # Punto de resonancia medido
        ax.plot(
            r['fr'],
            r['smin'],
            marker='o',
            markersize=5.5,
            markerfacecolor='white',
            markeredgecolor='black',
            markeredgewidth=1.1,
            zorder=6
        )

        # Anotacion tecnica de la resonancia
        texto_resonancia = (
            r'$f_r = $'
            + f"{r['fr']:.5f} GHz"
            + '\n'
            + r'$S_{11,\min} = $'
            + f"{r['smin']:.2f} dB"
        )

        ax.annotate(
            texto_resonancia,

            xy=(
                r['fr'],
                r['smin']
            ),

            xytext=(
                r['fr'] + 0.025,
                ymin + 3.2
            ),

            ha='left',
            va='bottom',
            fontsize=9,

            arrowprops={
                'arrowstyle': '-',
                'linewidth': 0.8,
                'color': 'black'
            }
        )

        # Ancho de banda
        if r['banda'] is not None:

            fL, fH, BW = r['banda']

            # Cruces de -10 dB
            ax.plot(
                [fL, fH],
                [UMBRAL_DB, UMBRAL_DB],
                linestyle='None',
                marker='o',
                markersize=4.5,
                markerfacecolor='white',
                markeredgecolor='#9b3838',
                markeredgewidth=1,
                zorder=6
            )

            # Lineas auxiliares
            ax.vlines(
                [fL, fH],
                ymin=UMBRAL_DB,
                ymax=-7.5,
                colors='#777777',
                linestyles=':',
                linewidth=0.9
            )

            # Marcador horizontal del ancho de banda
            ax.annotate(
                '',
                xy=(fL, -7.4),
                xytext=(fH, -7.4),

                arrowprops={
                    'arrowstyle': '|-|',
                    'linewidth': 0.8,
                    'color': 'black'
                }
            )

            # Valor del ancho de banda
            ax.text(
                (fL + fH)/2,
                -6.5,
                f'BW = {BW:.2f} MHz',
                ha='center',
                va='bottom',
                fontsize=9
            )

            # Identificacion de cortes
            ax.text(
                fL, -11.7,
                r'$f_L$',
                ha='center',
                va='top',
                fontsize=9
            )

            ax.text(
                fH, -11.7,
                r'$f_H$',
                ha='center',
                va='top',
                fontsize=9
            )

        # Leyenda
        ax.legend(
            loc='upper right',
            frameon=True,
            edgecolor='#aaaaaa',
            facecolor='white',
            framealpha=1,
            fontsize=8.5
        )

        exportar(
            fig,
            carpeta,
            'S11_detalle_academico'
        )

        return fig


    # ============================================================
    # 10. FIGURA DEL BARRIDO COMPLETO
    # ============================================================

    def figura_completa(f, s, r, carpeta):

        fig, ax = plt.subplots(
            figsize=(7.0, 4.3),
            constrained_layout=True
        )

        aplicar_estilo(
            ax,
            float(f.min()),
            float(f.max())
        )

        ax.set_title(
            'Caracterización experimental de la antena 4×2 fabricada\n'
            r'Parámetro $S_{11}$ medido — barrido completo de frecuencia',
            fontsize=11,
            fontweight='bold',
            fontfamily='serif',
            pad=16,
            loc='center'
        )

        # S11 completo
        ax.plot(
            f, s,
            color='black',
            linewidth=1.5,
            label=r'$S_{11}$ medido'
        )

        # Umbral
        ax.axhline(
            UMBRAL_DB,
            color='#9b3838',
            linestyle='--',
            linewidth=1,
            label=r'$-10$ dB'
        )

        # Frecuencia de diseño
        ax.axvline(
            F0_GHZ,
            color='#555555',
            linestyle=':',
            linewidth=0.9,
            label='2.45 GHz'
        )

        # Resonancia seleccionada
        ax.plot(
            r['fr'],
            r['smin'],
            marker='o',
            markerfacecolor='white',
            markeredgecolor='black',
            markersize=5
        )

        ax.legend(
            loc='lower left',
            fontsize=9,
            frameon=True,
            edgecolor='#aaaaaa'
        )

        exportar(
            fig,
            carpeta,
            'S11_barrido_academico'
        )

        return fig


    # ============================================================
    # 11. EJECUCION PRINCIPAL
    # ============================================================

    def main():

        archivo = elegir_archivo()

        if not archivo.is_file():
            raise FileNotFoundError(
                f'No existe el archivo: {archivo}'
            )

        # Lectura
        f, s = leer_csv(archivo)

        # Analisis
        r = analizar(f, s)

        # Carpeta de resultados
        carpeta = (
            archivo.parent
            / 'Figuras_S11_Academicas'
        )

        carpeta.mkdir(
            parents=True,
            exist_ok=True
        )

        # Generacion
        fig1 = figura_detalle(
            f, s, r, carpeta
        )

        fig2 = figura_completa(
            f, s, r, carpeta
        )

        # Resultados numericos
        print('\n=== S11 EXPERIMENTAL ===')

        print(
            f'Archivo: {archivo.name}'
        )

        print(
            f'Frecuencia resonante: '
            f'{r["fr"]:.6f} GHz'
        )

        print(
            f'S11 minimo: '
            f'{r["smin"]:.3f} dB'
        )

        print(
            f'S11 a 2.45 GHz: '
            f'{r["sf0"]:.3f} dB (interpolado)'
        )

        if r['banda'] is not None:

            fL, fH, BW = r['banda']

            print(
                f'Frecuencia inferior: '
                f'{fL:.6f} GHz'
            )

            print(
                f'Frecuencia superior: '
                f'{fH:.6f} GHz'
            )

            print(
                f'Ancho de banda: '
                f'{BW:.3f} MHz'
            )

        else:

            print(
                'No se encontro una banda cerrada '
                'a -10 dB alrededor de 2.45 GHz.'
            )

        print(
            f'Resolucion del barrido: '
            f'{r["paso_mhz"]:.3f} MHz'
        )

        print(
            f'Figuras exportadas en:\n{carpeta}'
        )

        if MOSTRAR_FIGURAS:
            plt.show()

        else:
            plt.close(fig1)
            plt.close(fig2)
    DPI_EXPORT = 600

    # Se utiliza la lectura/metodología existente, sin diálogos interactivos.
    F0_GHZ = f0
    MOSTRAR_FIGURAS = False
    if dpi is not None: DPI_EXPORT = dpi
    ruta_salida.mkdir(parents=True, exist_ok=True)
    f, s = leer_csv(ruta_datos)
    r = analizar(f, s)
    plt.close(figura_detalle(f, s, r, ruta_salida))
    plt.close(figura_completa(f, s, r, ruta_salida))
    resumen = ["DATOS EXPERIMENTALES - S11", f"Archivo: {ruta_datos.name}",
        f"Frecuencia de resonancia: {r['fr']:.6f} GHz",
        f"S11 minimo: {r['smin']:.4f} dB",
        f"S11({f0:.3f} GHz): {r['sf0']:.4f} dB"]
    if r.get('banda') is not None:
        fl, fh, bw = r['banda']
        resumen += [f"fL: {fl:.6f} GHz", f"fH: {fh:.6f} GHz", f"BW -10 dB: {bw:.3f} MHz"]
    (ruta_salida / "RESUMEN_S11_MEDIDO.txt").write_text("\n".join(resumen)+"\n", encoding="utf-8")
    print("   [OK] S11 experimental: 2 figuras y resumen")




# ====================================================================
# E. Cámara anecoica - XLS 2D
# ====================================================================
def _graficar_radiacion_2d_experimental(ruta_datos: Path, ruta_salida: Path, f0: float, dpi: int | None) -> None:

    # -*- coding: utf-8 -*-
    """
    FIGURAS ACADÉMICAS DE RADIACIÓN EXPERIMENTAL
    Antena microstrip 4x2 fabricada

    - Una figura independiente por magnitud
    - Patrones polares a 2450 MHz
    - Ancho de haz y ganancia frente a frecuencia
    - Tablas Features2D: una figura por variable
    - PDF vectorial y PNG a 600 dpi
    """

    from pathlib import Path
    import re
    import sys
    import unicodedata

    import numpy as np
    import pandas as pd
    import matplotlib.pyplot as plt
    from matplotlib.ticker import AutoMinorLocator


    # =====================================================
    # 1. CONFIGURACIÓN
    # =====================================================

    FRECUENCIA_MHZ = 2450.0

    DIRECTORIO_SALIDA = "Figuras_Radiacion_2D"

    MOSTRAR = False
    GUARDAR_PNG = True


    # =====================================================
    # 2. ESTILO ACADÉMICO
    # =====================================================

    plt.rcParams.update({
        "font.family": "serif",
        "font.serif": [
            "Times New Roman",
            "DejaVu Serif"
        ],
        "mathtext.fontset": "stix",
        "font.size": 9.5,
        "axes.linewidth": 0.85,
        "xtick.direction": "in",
        "ytick.direction": "in",
        "pdf.fonttype": 42,
        "ps.fonttype": 42,
        "savefig.facecolor": "white"
    })


    # =====================================================
    # 3. SELECCIÓN DE ARCHIVOS
    # =====================================================

    def seleccionar_archivos():

        if len(sys.argv) > 1:
            return [Path(a) for a in sys.argv[1:]]

        from tkinter import Tk, filedialog

        raiz = Tk()
        raiz.withdraw()
        raiz.attributes("-topmost", True)

        archivos = filedialog.askopenfilenames(
            title="Seleccione archivos XLS de radiación",
            filetypes=[
                ("Excel 97-2003", "*.xls"),
                ("Excel", "*.xlsx")
            ]
        )

        raiz.destroy()

        return [Path(x) for x in archivos]


    # =====================================================
    # 4. LECTURA DE EXCEL
    # =====================================================

    def leer_excel(ruta):

        motor = (
            "xlrd"
            if ruta.suffix.lower() == ".xls"
            else "openpyxl"
        )

        tabla = pd.read_excel(
            ruta,
            header=None,
            engine=motor
        )

        if tabla.shape[0] < 5:
            raise ValueError("Archivo sin datos suficientes.")

        return tabla


    def numero(valor):

        if pd.isna(valor):
            return np.nan

        if isinstance(valor, (int, float, np.number)):
            return float(valor)

        texto = str(valor).replace(",", ".")

        patron = re.search(
            r"[-+]?\d+(?:\.\d+)?",
            texto
        )

        return (
            float(patron.group(0))
            if patron
            else np.nan
        )


    def extraer_dos_columnas(tabla, columna=1):

        x = pd.to_numeric(
            tabla.iloc[4:, 0],
            errors="coerce"
        ).to_numpy(dtype=float)

        y = pd.to_numeric(
            tabla.iloc[4:, columna],
            errors="coerce"
        ).to_numpy(dtype=float)

        validos = np.isfinite(x) & np.isfinite(y)

        x = x[validos]
        y = y[validos]

        if len(x) < 3:
            raise ValueError("Datos numéricos insuficientes.")

        orden = np.argsort(x)

        return x[orden], y[orden]


    # =====================================================
    # 5. INFORMACIÓN DEL ARCHIVO
    # =====================================================

    def obtener_phi(nombre):

        patron = re.search(
            r"PhiCut\s*@?\s*([-+]?\d+(?:\.\d+)?)",
            nombre,
            re.IGNORECASE
        )

        if patron:
            return float(patron.group(1))

        return None


    def nombre_seguro(texto):

        texto = unicodedata.normalize("NFKD", texto)

        texto = "".join(
            c for c in texto
            if not unicodedata.combining(c)
        )

        return re.sub(
            r"[^A-Za-z0-9_-]+",
            "_",
            texto
        ).strip("_")[:115]


    # =====================================================
    # 6. EXPORTACIÓN INDEPENDIENTE
    # =====================================================

    def guardar(fig, carpeta, nombre):

        ruta = carpeta / nombre_seguro(nombre)

        fig.savefig(
            str(ruta) + ".pdf",
            bbox_inches="tight",
            pad_inches=0.13
        )

        if GUARDAR_PNG:

            fig.savefig(
                str(ruta) + ".png",
                dpi=DPI_EXPORT,
                bbox_inches="tight",
                pad_inches=0.13
            )

        print("Figura guardada:", ruta.name)

        if MOSTRAR:
            plt.show()

        plt.close(fig)


    # =====================================================
    # 7. ESTILO CARTESIANO
    # =====================================================

    def estilo_cartesiano(ax, xlabel, ylabel):

        ax.set_xlabel(xlabel, labelpad=7)
        ax.set_ylabel(ylabel, labelpad=7)

        ax.tick_params(
            which="both",
            top=True,
            right=True
        )

        ax.tick_params(
            which="major",
            length=5
        )

        ax.tick_params(
            which="minor",
            length=2.5
        )

        ax.xaxis.set_minor_locator(
            AutoMinorLocator(5)
        )

        ax.yaxis.set_minor_locator(
            AutoMinorLocator(2)
        )

        ax.grid(
            which="major",
            color="#d7d7d7",
            linewidth=0.55
        )

        ax.grid(
            which="minor",
            color="#ececec",
            linewidth=0.35
        )

        ax.set_axisbelow(True)


    # =====================================================
    # 8. PATRONES POLARES DE RADIACIÓN
    # =====================================================

    def grafica_angular(tabla, archivo, carpeta):

        # Detectar frecuencias de las columnas
        frecuencias = [
            numero(v)
            for v in tabla.iloc[0, 1:].to_list()
        ]

        distancias = np.abs(
            np.asarray(frecuencias, dtype=float)
            - FRECUENCIA_MHZ
        )

        if not np.any(np.isfinite(distancias)):
            raise ValueError("No se detectaron frecuencias.")

        columna = 1 + int(np.nanargmin(distancias))

        frecuencia_real = frecuencias[columna - 1]

        if abs(frecuencia_real - FRECUENCIA_MHZ) > 0.1:
            raise ValueError(
                "El archivo no contiene datos a 2450 MHz."
            )

        theta, ganancia = extraer_dos_columnas(
            tabla,
            columna
        )

        nombre = archivo.stem
        phi = obtener_phi(nombre)

        if "Gain_Abs_" in nombre:
            componente = "Ganancia absoluta"

        elif "AmpPhi" in nombre:
            componente = r"Componente $E_{\phi}$"

        else:
            componente = r"Componente $E_{\theta}$"

        # Desplazamiento gráfico para manejar
        # niveles negativos de ganancia en escala polar
        minimo_radial = (
            10 * np.floor(np.min(ganancia) / 10)
        )

        maximo_radial = (
            10 * np.ceil(np.max(ganancia) / 10)
        )

        if maximo_radial <= minimo_radial:
            maximo_radial = minimo_radial + 10

        radio = ganancia - minimo_radial

        indice_pico = int(np.argmax(ganancia))

        # Figura individual
        fig, ax = plt.subplots(
            figsize=(6.7, 6.2),
            subplot_kw={"projection": "polar"}
        )

        fig.subplots_adjust(
            left=0.09,
            right=0.91,
            bottom=0.13,
            top=0.81
        )

        # Broadside en la parte superior
        ax.set_theta_zero_location("N")
        ax.set_theta_direction(-1)

        angulos = np.arange(0, 360, 30)

        etiquetas = [
            f"{a if a <= 180 else a - 360}°"
            for a in angulos
        ]

        ax.set_thetagrids(
            angulos,
            labels=etiquetas
        )

        theta_rad = np.deg2rad(theta)

        # Curva experimental
        ax.plot(
            theta_rad,
            radio,
            color="black",
            linewidth=1.6
        )

        # Máximo del corte
        ax.plot(
            [theta_rad[indice_pico]],
            [radio[indice_pico]],
            marker="o",
            markersize=5,
            markerfacecolor="white",
            markeredgecolor="black",
            markeredgewidth=1.1,
            zorder=5
        )

        # Etiquetas radiales en dBi reales
        niveles = np.arange(
            minimo_radial + 10,
            maximo_radial + 0.01,
            10
        )

        ax.set_rticks(
            niveles - minimo_radial
        )

        ax.set_yticklabels([
            f"{v:.0f}"
            for v in niveles
        ])

        ax.set_ylim(
            0,
            maximo_radial - minimo_radial
        )

        ax.set_rlabel_position(135)

        ax.grid(
            color="#c5c5c5",
            linewidth=0.55
        )

        ax.spines["polar"].set_linewidth(0.9)

        # Título académico
        ax.set_title(
            "Patrón de radiación medido de la antena 4×2 fabricada\n"
            f"{componente} · "
            f"corte φ = {phi:g}° · "
            f"{frecuencia_real / 1000:.3f} GHz",
            fontsize=10.5,
            fontweight="bold",
            pad=23
        )

        # Información técnica inferior
        fig.text(
            0.5,
            0.055,
            f"Pico en el corte: "
            f"{ganancia[indice_pico]:.2f} dBi "
            f"a θ = {theta[indice_pico]:g}°"
            "   |   Escala radial: dBi",
            ha="center",
            fontsize=9
        )

        guardar(
            fig,
            carpeta,
            f"{nombre}_2450MHz_polar"
        )

        print(
            f"Máximo: {ganancia[indice_pico]:.2f} dBi; "
            f"θ = {theta[indice_pico]:g}°"
        )


    # =====================================================
    # 9. ANCHO DE HAZ Y GANANCIA VS FRECUENCIA
    # =====================================================

    def grafica_frecuencia(tabla, archivo, carpeta):

        frecuencia_mhz, valores = extraer_dos_columnas(
            tabla
        )

        frecuencia_ghz = frecuencia_mhz / 1000

        nombre = archivo.stem

        es_ancho_haz = (
            "beamwidth" in nombre.lower()
        )

        if es_ancho_haz:

            magnitud = "Ancho de haz a −3 dB"
            ylabel = "Ancho de haz a −3 dB (°)"
            unidad = "°"

        else:

            magnitud = (
                "Ganancia absoluta en "
                "θ = 0°, φ = 90°"
            )

            ylabel = "Ganancia absoluta (dBi)"
            unidad = "dBi"

        phi = obtener_phi(nombre)

        if phi is not None:
            magnitud += f" · φ = {phi:g}°"

        fig, ax = plt.subplots(
            figsize=(7, 4.5),
            constrained_layout=True
        )

        estilo_cartesiano(
            ax,
            "Frecuencia (GHz)",
            ylabel
        )

        ax.plot(
            frecuencia_ghz,
            valores,
            color="black",
            linewidth=1.65
        )

        # Referencia a 2.45 GHz
        f0 = FRECUENCIA_MHZ / 1000

        if frecuencia_ghz[0] <= f0 <= frecuencia_ghz[-1]:

            valor_f0 = float(np.interp(
                f0,
                frecuencia_ghz,
                valores
            ))

            ax.plot(
                [f0],
                [valor_f0],
                marker="o",
                markersize=5.5,
                markerfacecolor="white",
                markeredgecolor="black",
                markeredgewidth=1.1,
                zorder=5
            )

            ax.axvline(
                f0,
                linestyle=":",
                linewidth=0.9,
                color="#666666"
            )

            ax.annotate(
                f"2.450 GHz; {valor_f0:.2f} {unidad}",
                xy=(f0, valor_f0),
                xytext=(12, 14),
                textcoords="offset points",
                fontsize=9,
                arrowprops={
                    "arrowstyle": "-",
                    "linewidth": 0.7,
                    "color": "#555555"
                }
            )

        ax.set_title(
            "Medición experimental de la antena 4×2 fabricada\n"
            f"{magnitud}",
            fontsize=10.5,
            fontweight="bold",
            pad=14
        )

        guardar(
            fig,
            carpeta,
            f"{nombre}_frecuencia"
        )


    # =====================================================
    # 10. MÉTRICAS Features2D
    # =====================================================

    def graficas_features(tabla, archivo, carpeta):

        # Cada métrica tendrá su figura individual.

        frecuencia_mhz = pd.to_numeric(
            tabla.iloc[4:, 0],
            errors="coerce"
        ).to_numpy(dtype=float)

        nombre = archivo.stem
        phi = obtener_phi(nombre)

        titulos = [
            "Magnitud máxima del patrón",
            "Dirección angular del máximo",
            "Ancho de haz a −3 dB",
            "Nivel de lóbulos secundarios"
        ]

        etiquetas = [
            "Magnitud pico (unidad exportada)",
            "Ángulo del máximo (°)",
            "Ancho de haz (°)",
            "SideLobe (unidad exportada)"
        ]

        nombres = [
            "pico",
            "direccion_pico",
            "ancho_haz",
            "sidelobe"
        ]

        for columna in range(
            1,
            min(5, tabla.shape[1])
        ):

            valores = pd.to_numeric(
                tabla.iloc[4:, columna],
                errors="coerce"
            ).to_numpy(dtype=float)

            validos = (
                np.isfinite(frecuencia_mhz)
                & np.isfinite(valores)
            )

            if np.count_nonzero(validos) < 3:
                continue

            f = frecuencia_mhz[validos] / 1000
            y = valores[validos]

            orden = np.argsort(f)
            f = f[orden]
            y = y[orden]

            fig, ax = plt.subplots(
                figsize=(7, 4.4),
                constrained_layout=True
            )

            estilo_cartesiano(
                ax,
                "Frecuencia (GHz)",
                etiquetas[columna - 1]
            )

            ax.plot(
                f,
                y,
                color="black",
                linewidth=1.55
            )

            f0 = FRECUENCIA_MHZ / 1000

            if f[0] <= f0 <= f[-1]:

                valor = float(
                    np.interp(f0, f, y)
                )

                ax.plot(
                    [f0],
                    [valor],
                    marker="o",
                    markerfacecolor="white",
                    markeredgecolor="black",
                    markeredgewidth=1.1,
                    markersize=5
                )

                ax.axvline(
                    f0,
                    linestyle=":",
                    color="#666666",
                    linewidth=0.85
                )

                ax.annotate(
                    f"{valor:.2f}",
                    xy=(f0, valor),
                    xytext=(9, 12),
                    textcoords="offset points",
                    fontsize=9
                )

            ax.set_title(
                "Medición experimental de la antena 4×2 fabricada\n"
                f"{titulos[columna - 1]} · "
                f"φ = {phi:g}°",
                fontsize=10.5,
                fontweight="bold",
                pad=14
            )

            guardar(
                fig,
                carpeta,
                f"{nombre}_{nombres[columna - 1]}"
            )

        print(
            "Revisar las unidades originales de "
            "PeakMagn y SideLobe antes de citarlas."
        )


    # =====================================================
    # 11. PROCESAMIENTO DE ARCHIVOS
    # =====================================================

    def main():

        archivos = seleccionar_archivos()

        if not archivos:

            print("No se seleccionaron archivos.")
            return

        for archivo in archivos:

            print("\nArchivo:", archivo.name)

            try:

                tabla = leer_excel(archivo)

                carpeta = (
                    archivo.parent
                    / DIRECTORIO_SALIDA
                )

                carpeta.mkdir(
                    parents=True,
                    exist_ok=True
                )

                nombre = archivo.name.lower()

                if nombre.startswith("features2d_"):

                    graficas_features(
                        tabla,
                        archivo,
                        carpeta
                    )

                elif (
                    "beamwidth" in nombre
                    or "gain_abs in dbi" in nombre
                ):

                    grafica_frecuencia(
                        tabla,
                        archivo,
                        carpeta
                    )

                elif "phicut@" in nombre:

                    grafica_angular(
                        tabla,
                        archivo,
                        carpeta
                    )

                else:

                    print(
                        "Tipo de medición no reconocido."
                    )

            except Exception as error:

                print(
                    "ERROR:",
                    type(error).__name__,
                    str(error)
                )

        print(
            "\nProceso finalizado. "
            "Las gráficas se guardaron individualmente."
        )
    DPI_EXPORT = 600

    # Se procesan automáticamente todos los XLS 2D de la cámara.
    MOSTRAR = False
    GUARDAR_PNG = True
    if dpi is not None: DPI_EXPORT = dpi
    FRECUENCIA_MHZ = f0 * 1000.0
    ruta_salida.mkdir(parents=True, exist_ok=True)
    procesados, errores = 0, []
    for archivo in sorted(ruta_datos.glob("*.xls")):
        print("   2D:", archivo.name)
        try:
            tabla = leer_excel(archivo)
            nombre = archivo.name.lower()
            if nombre.startswith("features2d_"):
                graficas_features(tabla, archivo, ruta_salida)
            elif "beamwidth" in nombre or "gain_abs in dbi" in nombre:
                grafica_frecuencia(tabla, archivo, ruta_salida)
            elif "phicut@" in nombre:
                grafica_angular(tabla, archivo, ruta_salida)
            else:
                print("   [OMITIDO] XLS no reconocido:", archivo.name)
                continue
            procesados += 1
        except Exception as error:
            errores.append((archivo.name, str(error)))
            print("   [ERROR]", archivo.name, str(error))
    if not list(ruta_datos.glob("*.xls")):
        raise FileNotFoundError(f"No hay archivos XLS en {ruta_datos}")
    if errores:
        (ruta_salida / "ERRORES_RADIACION_2D.txt").write_text(
            "\n".join(f"{nombre}: {e}" for nombre, e in errores), encoding="utf-8")
    print(f"   [2D] Archivos procesados: {procesados}; con errores: {len(errores)}")
    if procesados == 0:
        raise RuntimeError("No se pudo procesar ningún XLS 2D. Revisa xlrd y los archivos.")




# ====================================================================
# F. Cámara anecoica - XLS 3D y cortes
# ====================================================================
def _graficar_radiacion_3d_experimental(ruta_datos: Path, ruta_salida: Path, f0: float, dpi: int | None) -> None:

    # -*- coding: utf-8 -*-
    """
    ANÁLISIS EXPERIMENTAL DE RADIACIÓN
    Antena microstrip 4x2 fabricada - Tesis de grado

    Por cada archivo XLS 3D se generan cinco figuras:
      1. Patrón de radiación tridimensional
      2. Patrón cartesiano phi = 0 grados
      3. Patrón polar phi = 0 grados
      4. Patrón cartesiano phi = 90 grados
      5. Patrón polar phi = 90 grados

    Cada figura se exporta individualmente como:
      - PDF vectorial
      - PNG de alta resolución

    Los datos medidos no se suavizan.
    Los cruces de -3 dB se interpolan linealmente.
    """

    from pathlib import Path
    from tkinter import Tk, filedialog

    import io
    import re
    import sys

    import numpy as np
    import matplotlib.pyplot as plt

    from matplotlib import colors, cm
    from matplotlib.ticker import MultipleLocator, AutoMinorLocator
    from scipy.signal import find_peaks


    # ============================================================
    # 1. CONFIGURACIÓN GENERAL
    # ============================================================

    # Vacío: seleccionar los archivos mediante una ventana.
    ARCHIVOS = []

    CARPETA_SALIDA = "Figuras_Radiacion_Tesis"

    MOSTRAR_FIGURAS = True

    RESOLUCION_PNG = 600

    # Ventana dinámica empleada únicamente para el radio 3D.
    RANGO_RADIAL_DB = 35.0

    # Escala absoluta de colores común para todas las figuras 3D.
    ESCALA_COLOR_DBI = (-30, 15)

    # Ángulos de cámara.
    CAMARA_ELEVACION = 20
    CAMARA_AZIMUT = -63

    # Acercamiento de cámara.
    ZOOM_3D = 1.45


    # ============================================================
    # 2. ESTILO ACADÉMICO
    # ============================================================

    plt.rcParams.update({

        "font.family": "serif",

        "font.serif": [
            "Times New Roman",
            "DejaVu Serif"
        ],

        "mathtext.fontset": "stix",

        "font.size": 10,

        "axes.linewidth": 0.9,

        "pdf.fonttype": 42,
        "ps.fonttype": 42,

        "figure.facecolor": "white",
        "savefig.facecolor": "white"

    })


    # ============================================================
    # 3. SELECCIÓN DE ARCHIVOS
    # ============================================================

    def seleccionar_archivos():

        if len(sys.argv) > 1:
            return [Path(p) for p in sys.argv[1:]]

        if ARCHIVOS:
            return [Path(p) for p in ARCHIVOS]

        ventana = Tk()
        ventana.withdraw()
        ventana.attributes("-topmost", True)

        archivos = filedialog.askopenfilenames(

            title="Seleccione los archivos XLS 3D de la cámara",

            filetypes=[
                ("Excel 97-2003", "*.xls")
            ]
        )

        ventana.destroy()

        return [Path(p) for p in archivos]


    # ============================================================
    # 4. LECTURA DE DATOS EXPERIMENTALES
    # ============================================================

    def leer_xls(ruta):

        import xlrd

        # Lectura directa para evitar la advertencia de Pandas
        # sobre la futura eliminación del motor xlrd.

        libro = xlrd.open_workbook(
            str(ruta),
            logfile=io.StringIO()
        )

        hoja = libro.sheet_by_index(0)

        datos = []

        # Columnas verificadas del formato SPM:
        # 0: Azimuth (grados)
        # 1: Elevation (grados)
        # 2: Ganancia absoluta (dBi)

        for fila in range(hoja.nrows):

            if hoja.row_len(fila) < 3:
                continue

            try:

                azimut, elevacion, ganancia = (
                    float(hoja.cell_value(fila, j))
                    for j in range(3)
                )

            except (ValueError, TypeError):
                continue

            valores = [
                azimut,
                elevacion,
                ganancia
            ]

            if not np.isfinite(valores).all():
                continue

            if not (
                0 <= azimut <= 360
                and 0 <= elevacion <= 180
            ):
                continue

            datos.append(valores)

        datos = np.asarray(datos, dtype=float)

        if datos.ndim != 2 or len(datos) < 100:

            raise ValueError(
                "No se reconocieron las muestras angulares."
            )

        azimuts = np.unique(datos[:, 0])
        elevaciones = np.unique(datos[:, 1])

        if len(azimuts) * len(elevaciones) != len(datos):

            raise ValueError(
                "La malla está incompleta o contiene "
                "posiciones angulares duplicadas."
            )

        # Reconstrucción exacta de la malla medida.
        # No se interpolan muestras faltantes.

        diccionario = {
            (az, el): g
            for az, el, g in datos
        }

        try:

            G = np.array([

                [
                    diccionario[(az, el)]
                    for az in azimuts
                ]

                for el in elevaciones

            ])

        except KeyError:

            raise ValueError(
                "La malla angular no es rectangular."
            )

        AZ, EL = np.meshgrid(
            azimuts,
            elevaciones
        )

        return AZ, EL, G


    # ============================================================
    # 5. FRECUENCIA DE CADA ARCHIVO
    # ============================================================

    def obtener_frecuencia(ruta):

        resultado = re.search(

            r"(\d+(?:\.\d+)?)\s*MHz",

            ruta.name,

            re.IGNORECASE
        )

        if resultado is None:

            raise ValueError(
                "El archivo debe incluir la frecuencia en MHz."
            )

        return float(resultado.group(1))


    # ============================================================
    # 6. EXPORTACIÓN DE FIGURAS
    # ============================================================

    def guardar_figura(figura, destino):

        figura.savefig(

            str(destino) + ".pdf",

            bbox_inches="tight",
            pad_inches=0.16
        )

        figura.savefig(

            str(destino) + ".png",

            dpi=RESOLUCION_PNG,
            bbox_inches="tight",
            pad_inches=0.16
        )

        if MOSTRAR_FIGURAS:
            plt.show()

        plt.close(figura)


    # ============================================================
    # 7. CONVERSIÓN DEL PATRÓN A SUPERFICIE 3D
    # ============================================================

    def construir_superficie(AZ, EL, G):

        ganancia_maxima = float(G.max())

        # Transformación para representación geométrica.
        # Los valores originales permanecen inalterados.

        R = np.clip(

            (
                G - (ganancia_maxima - RANGO_RADIAL_DB)
            ) / RANGO_RADIAL_DB,

            0,
            1
        )

        R = 0.025 + 0.975 * R

        # Convención para la visualización:
        # Azimuth se interpreta como phi.
        # Elevation se representa como ángulo desde +Z.
        # Esta correspondencia debe contrastarse con
        # la orientación utilizada en la cámara.

        phi = np.deg2rad(AZ)
        theta = np.deg2rad(EL)

        X = R * np.sin(theta) * np.cos(phi)
        Y = R * np.sin(theta) * np.sin(phi)
        Z = R * np.cos(theta)

        return X, Y, Z


    # ============================================================
    # 8. PATRÓN TRIDIMENSIONAL ACADÉMICO
    # ============================================================

    def grafica_3d(AZ, EL, G, frecuencia, destino):

        X, Y, Z = construir_superficie(
            AZ, EL, G
        )

        figura = plt.figure(
            figsize=(8, 7.7),
            facecolor="white"
        )

        ax = figura.add_axes(

            [0.005, 0.055, 0.82, 0.83],

            projection="3d"
        )

        # Colores tradicionales de diagramas de antenas.

        mapa = plt.get_cmap("jet")

        normalizador = colors.Normalize(
            *ESCALA_COLOR_DBI
        )

        colores = mapa(
            normalizador(G)
        )

        # Superficie con malla negra.

        ax.plot_surface(

            X, Y, Z,

            facecolors=colores,

            linewidth=0.24,

            edgecolor=(0, 0, 0, 0.38),

            shade=False,

            antialiased=True,

            rstride=2,
            cstride=3
        )

        # --------------------------------------------------------
        # Ejes espaciales de referencia
        # --------------------------------------------------------

        ejes = [

            ((0.90, 0, 0), "x"),
            ((0, 0.90, 0), "y"),
            ((0, 0, 1.10), "z")

        ]

        for vector, etiqueta in ejes:

            ax.quiver(

                0, 0, 0,

                *vector,

                color="#333333",

                linewidth=0.95,

                arrow_length_ratio=0.065
            )

            ax.text(

                *(np.asarray(vector) * 1.05),

                etiqueta,

                fontsize=12,

                fontweight="bold"
            )

        # --------------------------------------------------------
        # Lóbulo principal: máximo absoluto medido
        # --------------------------------------------------------

        indice_max = np.unravel_index(

            np.argmax(G),
            G.shape
        )

        ax.scatter(

            [X[indice_max]],
            [Y[indice_max]],
            [Z[indice_max]],

            s=26,

            color="black",

            depthshade=False
        )

        ax.text(

            X[indice_max] + 0.16,
            Y[indice_max] - 0.15,
            Z[indice_max] + 0.09,

            "Lóbulo principal",

            fontsize=8.4
        )

        # --------------------------------------------------------
        # Referencia de radiación secundaria
        # --------------------------------------------------------

        azimuts = np.unique(AZ)
        elevaciones = np.unique(EL)

        columna = int(
            np.argmin(np.abs(azimuts - 0))
        )

        indices = np.flatnonzero(

            (elevaciones > 35)
            & (elevaciones < 80)
        )

        if len(indices):

            fila = int(

                indices[
                    np.argmax(G[indices, columna])
                ]

            )

            ax.scatter(

                [X[fila, columna]],
                [Y[fila, columna]],
                [Z[fila, columna]],

                s=13,

                color="#161616",

                depthshade=False
            )

            ax.text(

                X[fila, columna] + 0.05,

                Y[fila, columna] - 0.07,

                Z[fila, columna] + 0.04,

                "Lóbulo lateral",

                fontsize=8
            )

        # --------------------------------------------------------
        # Cámara y presentación espacial
        # --------------------------------------------------------

        ax.set(
            xlim=(-0.9, 0.9),
            ylim=(-0.9, 0.9),
            zlim=(-0.45, 1.28)
        )

        ax.set_box_aspect(

            (1.55, 1.55, 1.73),

            zoom=ZOOM_3D
        )

        ax.view_init(

            elev=CAMARA_ELEVACION,

            azim=CAMARA_AZIMUT
        )

        # Sin caja cúbica alrededor de la figura.
        ax.set_axis_off()

        # --------------------------------------------------------
        # Barra de ganancia absoluta
        # --------------------------------------------------------

        escala = cm.ScalarMappable(

            norm=normalizador,
            cmap=mapa
        )

        eje_color = figura.add_axes(
            [0.90, 0.28, 0.020, 0.44]
        )

        barra = figura.colorbar(

            escala,

            cax=eje_color
        )

        barra.set_label(

            "Ganancia absoluta medida (dBi)",

            fontsize=9
        )

        barra.ax.tick_params(
            labelsize=8
        )

        # --------------------------------------------------------
        # Título y datos experimentales
        # --------------------------------------------------------

        figura.suptitle(

            "Patrón tridimensional de radiación medido",

            fontsize=13,

            fontweight="bold",

            y=0.975
        )

        figura.text(

            0.48, 0.931,

            "Antena microstrip 4×2 fabricada"
            f" — {frecuencia / 1000:.3f} GHz",

            ha="center",

            fontsize=10
        )

        figura.text(

            0.50, 0.048,

            f"Ganancia máxima: {G.max():.2f} dBi"
            "    ·    Radio de visualización: "
            f"normalizado ({RANGO_RADIAL_DB:g} dB)",

            ha="center",

            fontsize=8.5
        )

        guardar_figura(figura, destino)


    # ============================================================
    # 9. EXTRAER UN CORTE 2D DESDE LA MALLA 3D
    # ============================================================

    def extraer_corte(AZ, EL, G, phi):

        azimuts = np.unique(AZ)
        elevaciones = np.unique(EL)

        # Corte positivo: phi.
        # Corte negativo: azimut opuesto phi+180.

        positivo = np.flatnonzero(

            np.isclose(azimuts, phi)
        )

        opuesto = np.flatnonzero(

            np.isclose(
                azimuts,
                (phi + 180) % 360
            )
        )

        if not len(positivo) or not len(opuesto):

            raise ValueError(
                f"No existen ambos semiplanos para phi={phi}."
            )

        # Ángulo firmado: -165° a +165°.
        # No se crea información artificial en +/-180°.

        theta = np.r_[

            -elevaciones[:0:-1],

            elevaciones
        ]

        ganancia = np.r_[

            G[:0:-1, int(opuesto[0])],

            G[:, int(positivo[0])]
        ]

        return theta, ganancia


    # ============================================================
    # 10. INTERPOLACIÓN LINEAL
    # ============================================================

    def interpolar(x1, y1, x2, y2, nivel):

        if abs(y2 - y1) < 1e-12:
            return (x1 + x2) / 2

        return (

            x1

            + (nivel - y1)
            * (x2 - x1)
            / (y2 - y1)

        )


    # ============================================================
    # 11. CÁLCULO DE HPBW, NULOS Y SLL
    # ============================================================

    def calcular_metricas(theta, ganancia):

        # Máximo dentro del sector próximo al broadside.
        # Se utiliza para identificar el lóbulo principal.

        sector = np.flatnonzero(

            np.abs(theta) <= 25
        )

        indice = int(

            sector[
                np.argmax(ganancia[sector])
            ]

        )

        gmax = ganancia[indice]

        ganancia_relativa = ganancia - gmax

        # --------------------------------------------------------
        # HPBW: cruces a -3 dB
        # --------------------------------------------------------

        nivel = -3.0

        izquierda = indice

        while (
            izquierda > 0
            and ganancia_relativa[izquierda - 1] >= nivel
        ):

            izquierda -= 1

        derecha = indice

        while (
            derecha < len(theta) - 1
            and ganancia_relativa[derecha + 1] >= nivel
        ):

            derecha += 1

        if izquierda > 0:

            limite_izquierdo = interpolar(

                theta[izquierda - 1],
                ganancia_relativa[izquierda - 1],

                theta[izquierda],
                ganancia_relativa[izquierda],

                nivel
            )

        else:

            limite_izquierdo = np.nan

        if derecha < len(theta) - 1:

            limite_derecho = interpolar(

                theta[derecha],
                ganancia_relativa[derecha],

                theta[derecha + 1],
                ganancia_relativa[derecha + 1],

                nivel
            )

        else:

            limite_derecho = np.nan

        if np.isfinite(limite_izquierdo + limite_derecho):

            HPBW = limite_derecho - limite_izquierdo

        else:

            HPBW = None

        # --------------------------------------------------------
        # Primeros mínimos suficientemente pronunciados
        # --------------------------------------------------------

        minimos, _ = find_peaks(

            -ganancia,

            prominence=3.0,

            distance=3
        )

        candidatos_izquierda = [

            k for k in minimos

            if -90 < theta[k] < theta[indice] - 5

        ]

        candidatos_derecha = [

            k for k in minimos

            if theta[indice] + 5 < theta[k] < 90

        ]

        nulo_izquierdo = (

            max(candidatos_izquierda)

            if candidatos_izquierda else None

        )

        nulo_derecho = (

            min(candidatos_derecha)

            if candidatos_derecha else None

        )

        FNBW = None

        if (

            nulo_izquierdo is not None

            and nulo_derecho is not None

        ):

            FNBW = (

                theta[nulo_derecho]

                - theta[nulo_izquierdo]

            )

        # --------------------------------------------------------
        # SLL: máximo secundario del corte
        # --------------------------------------------------------

        SLL = None
        indice_secundario = None

        # Solo se estima si se reconocen ambos
        # mínimos que delimitan el lóbulo principal.

        if FNBW is not None:

            maximos, _ = find_peaks(

                ganancia,

                prominence=2.5,

                distance=3
            )

            candidatos = [

                k for k in maximos

                if (
                    k < nulo_izquierdo

                    or k > nulo_derecho
                )

                and abs(theta[k]) <= 100

            ]

            if candidatos:

                indice_secundario = max(

                    candidatos,

                    key=lambda k: ganancia[k]
                )

                SLL = (

                    ganancia[indice_secundario]

                    - gmax

                )

        return {

            "indice": indice,

            "ganancia_max": gmax,

            "normalizada": ganancia_relativa,

            "limite_izquierdo": limite_izquierdo,

            "limite_derecho": limite_derecho,

            "HPBW": HPBW,

            "nulo_izquierdo": nulo_izquierdo,

            "nulo_derecho": nulo_derecho,

            "FNBW": FNBW,

            "indice_secundario": indice_secundario,

            "SLL": SLL

        }


    # ============================================================
    # 12. FORMATO CARTESIANO
    # ============================================================

    def estilo_cartesiano(ax):

        ax.set_xlabel(
            r"Ángulo $\theta$ (°)",
            fontsize=11
        )

        ax.set_ylabel(
            "Ganancia normalizada (dB)",
            fontsize=11
        )

        ax.set_xlim(-165, 165)

        ax.set_ylim(-37, 3)

        ax.xaxis.set_major_locator(
            MultipleLocator(30)
        )

        ax.xaxis.set_minor_locator(
            MultipleLocator(10)
        )

        ax.yaxis.set_major_locator(
            MultipleLocator(5)
        )

        ax.yaxis.set_minor_locator(
            AutoMinorLocator(2)
        )

        ax.tick_params(

            which="both",

            direction="in",

            top=True,
            right=True
        )

        ax.grid(

            which="major",

            linewidth=0.45,

            color="#dddddd"
        )

        ax.grid(

            which="minor",

            linewidth=0.24,

            color="#eeeeee"
        )


    # ============================================================
    # 13. GRÁFICA 2D CARTESIANA CON ANOTACIONES
    # ============================================================

    def grafica_cartesiana(
        theta, ganancia, M,
        frecuencia, phi, destino
    ):

        figura, ax = plt.subplots(

            figsize=(8.3, 5.2)
        )

        figura.subplots_adjust(

            top=0.80,

            bottom=0.19,

            left=0.10,

            right=0.96
        )

        estilo_cartesiano(ax)

        relativa = M["normalizada"]

        indice = M["indice"]

        # Relleno discreto del patrón angular.
        ax.fill_between(

            theta,

            np.maximum(relativa, -37),

            -37,

            color="#9cbed6",

            alpha=0.22,

            zorder=1
        )

        ni = M["nulo_izquierdo"]
        nd = M["nulo_derecho"]

        # Destacar región del lóbulo principal
        # cuando sus primeros mínimos son detectables.

        if ni is not None and nd is not None:

            ax.fill_between(

                theta[ni:nd+1],

                np.maximum(
                    relativa[ni:nd+1],
                    -37
                ),

                -37,

                color="#cfab5b",

                alpha=0.24,

                zorder=1
            )

        # Curva experimental
        ax.plot(

            theta,
            relativa,

            color="black",

            linewidth=1.5,

            zorder=3
        )

        # Referencia de -3 dB
        ax.axhline(

            -3,

            linestyle="--",

            color="#8a3333",

            linewidth=1.0
        )

        # Dirección broadside
        ax.axvline(

            0,

            linestyle=":",

            color="#777777",

            linewidth=0.8
        )

        # --------------------------------------------------------
        # Máximo y lóbulo principal
        # --------------------------------------------------------

        ax.scatter(

            [theta[indice]],

            [0],

            s=28,

            color="black",

            zorder=5
        )

        ax.annotate(

            "Lóbulo principal",

            xy=(theta[indice], 0),

            xytext=(58, -3),

            fontsize=9,

            arrowprops=dict(

                arrowstyle="-",

                linewidth=0.8
            ),

            ha="center"
        )

        # --------------------------------------------------------
        # HPBW
        # --------------------------------------------------------

        if M["HPBW"] is not None:

            li = M["limite_izquierdo"]
            ld = M["limite_derecho"]

            ax.annotate(

                "",

                xy=(li, -3.4),

                xytext=(ld, -3.4),

                arrowprops=dict(

                    arrowstyle="<->",

                    linewidth=0.8
                )
            )

            ax.text(

                (li + ld)/2,

                -7,

                f'HPBW = {M["HPBW"]:.2f}°',

                ha="center",

                fontsize=9
            )

            ax.plot(

                [li, ld],

                [-3, -3],

                marker="o",

                linestyle="None",

                markersize=4,

                color="#8a3333"
            )

        # --------------------------------------------------------
        # Lóbulo secundario / SLL
        # --------------------------------------------------------

        if M["indice_secundario"] is not None:

            k = M["indice_secundario"]

            ax.plot(

                theta[k],

                relativa[k],

                "o",

                markersize=4,

                color="#333333"
            )

            if theta[k] < 0:

                posicion_texto = (-112, -10)

            else:

                posicion_texto = (106, -10)

            ax.annotate(

                "Lóbulo lateral\n"
                f'SLL = {M["SLL"]:.2f} dB',

                xy=(theta[k], relativa[k]),

                xytext=posicion_texto,

                fontsize=9,

                ha="center",

                arrowprops=dict(

                    arrowstyle="-",

                    linewidth=0.75
                )
            )

        # --------------------------------------------------------
        # Primeros mínimos / FNBW
        # --------------------------------------------------------

        if M["FNBW"] is not None:

            ax.scatter(

                [theta[ni], theta[nd]],

                [relativa[ni], relativa[nd]],

                color="#333333",

                s=22,

                zorder=4
            )

            ax.text(

                0,

                -33.5,

                f'FNBW ≈ {M["FNBW"]:.1f}°'
                " (entre primeros mínimos)",

                fontsize=8.5,

                ha="center"
            )

        # --------------------------------------------------------
        # Título y precisión metodológica
        # --------------------------------------------------------

        ax.set_title(

            "Patrón angular medido de la antena 4×2 fabricada\n"

            f"Corte φ = {phi}°"
            f" · {frecuencia/1000:.3f} GHz",

            fontsize=11,

            fontweight="bold",

            pad=11
        )

        figura.text(

            0.5, 0.054,

            "Cobertura angular: −165° a +165°; "
            "no se estimó F/B en 180°.",

            ha="center",

            fontsize=8,

            color="#555555"
        )

        guardar_figura(figura, destino)


    # ============================================================
    # 14. DIAGRAMA POLAR
    # ============================================================

    def grafica_polar(
        theta, ganancia, M,
        frecuencia, phi, destino
    ):

        figura = plt.figure(

            figsize=(6.5, 6.3)
        )

        ax = figura.add_axes(

            [0.10, 0.10, 0.78, 0.72],

            projection="polar"
        )

        relativa = M["normalizada"]

        # Radio desplazado para representar dB negativos.
        radio = np.clip(
            relativa, -35, 0
        ) + 35

        ax.set_theta_zero_location("N")

        ax.set_theta_direction(-1)

        ax.plot(

            np.deg2rad(theta),

            radio,

            color="#151515",

            linewidth=1.5
        )

        # --------------------------------------------------------
        # Escala radial de ganancia normalizada
        # --------------------------------------------------------

        ax.set_rlim(0, 35)

        ax.set_rticks([
            5, 15, 25, 35
        ])

        ax.set_yticklabels([
            "−30", "−20", "−10", "0"
        ])

        ax.set_rlabel_position(135)

        angulos = np.arange(0, 360, 30)

        etiquetas = [

            f"{int(a if a <= 180 else a-360)}°"

            for a in angulos
        ]

        ax.set_thetagrids(

            angulos,

            labels=etiquetas
        )

        ax.grid(

            color="#bbbbbb",

            linewidth=0.55
        )

        # --------------------------------------------------------
        # Máximo de radiación
        # --------------------------------------------------------

        indice = M["indice"]

        ax.scatter(

            [np.deg2rad(theta[indice])],

            [radio[indice]],

            s=23,

            color="#111111"
        )

        # --------------------------------------------------------
        # Límites de HPBW
        # --------------------------------------------------------

        if M["HPBW"] is not None:

            limites = [

                M["limite_izquierdo"],

                M["limite_derecho"]

            ]

            for angulo in limites:

                ax.plot(

                    [np.deg2rad(angulo)] * 2,

                    [0, 32],

                    color="#8a3333",

                    linestyle="--",

                    linewidth=0.8
                )

        # --------------------------------------------------------
        # Título académico
        # --------------------------------------------------------

        figura.text(

            0.5, 0.93,

            "Patrón polar medido de la antena 4×2 fabricada",

            ha="center",

            fontsize=11,

            fontweight="bold"
        )

        figura.text(

            0.5, 0.89,

            f"φ = {phi}°"
            f"   ·   f = {frecuencia/1000:.3f} GHz"
            "   ·   Escala normalizada (dB)",

            ha="center",

            fontsize=9.5
        )

        if M["HPBW"] is not None:

            texto_hpbw = f'HPBW: {M["HPBW"]:.2f}°'

        else:

            texto_hpbw = "HPBW: no determinado"

        figura.text(

            0.5, 0.045,

            f'Máximo del corte: {M["ganancia_max"]:.2f} dBi'
            f"    ·    {texto_hpbw}",

            ha="center",

            fontsize=9
        )

        guardar_figura(figura, destino)


    # ============================================================
    # 15. PROGRAMA PRINCIPAL
    # ============================================================

    def main():

        archivos = seleccionar_archivos()

        if not archivos:

            print("Selección cancelada.")
            return

        for ruta in archivos:

            try:

                print("\nProcesando:", ruta.name)

                # Lectura y frecuencia
                AZ, EL, G = leer_xls(ruta)

                frecuencia = obtener_frecuencia(ruta)

                # Carpeta de resultados
                destino = ruta.parent / CARPETA_SALIDA

                destino.mkdir(
                    parents=True,
                    exist_ok=True
                )

                nombre = f"Medido_{frecuencia:.0f}MHz"

                # ----------------------------------------------
                # FIGURA 1: Radiación tridimensional
                # ----------------------------------------------

                grafica_3d(

                    AZ, EL, G,

                    frecuencia,

                    destino / f"{nombre}_01_3D"
                )

                # ----------------------------------------------
                # FIGURAS DE APOYO PARA CADA CORTE
                # ----------------------------------------------

                for phi in (0, 90):

                    theta, ganancia = extraer_corte(

                        AZ, EL, G, phi
                    )

                    M = calcular_metricas(

                        theta,
                        ganancia
                    )

                    # Figura cartesiana independiente
                    grafica_cartesiana(

                        theta,
                        ganancia,
                        M,

                        frecuencia,
                        phi,

                        destino / (
                            f"{nombre}_Phi{phi:02d}"
                            "_02_Cartesiano"
                        )
                    )

                    # Figura polar independiente
                    grafica_polar(

                        theta,
                        ganancia,
                        M,

                        frecuencia,
                        phi,

                        destino / (
                            f"{nombre}_Phi{phi:02d}"
                            "_03_Polar"
                        )
                    )

                    # Resultados
                    print(f"\nCorte phi = {phi}°")

                    print(
                        "Ganancia máxima:",
                        f'{M["ganancia_max"]:.2f} dBi'
                    )

                    print(
                        "HPBW:",
                        M["HPBW"]
                    )

                    print(
                        "FNBW:",
                        M["FNBW"]
                    )

                    print(
                        "SLL:",
                        M["SLL"]
                    )

                print(
                    "\nFiguras guardadas en:",
                    destino
                )

            except Exception as error:

                print(

                    "ERROR:",

                    type(error).__name__,

                    error
                )

        print("\nProceso finalizado.")

    # El análisis volumétrico, HPBW y cortes permanecen sin suavizado.
    MOSTRAR_FIGURAS = False
    if dpi is not None: RESOLUCION_PNG = dpi
    ruta_salida.mkdir(parents=True, exist_ok=True)
    procesados, errores, registros = 0, [], []
    for archivo in sorted(ruta_datos.glob("TransformedData_Gain_Abs_dBi_*MHz_SPM.xls")):
        print("   3D:", archivo.name)
        try:
            AZ, EL, G = leer_xls(archivo)
            frecuencia = obtener_frecuencia(archivo)
            base = f"Medido_{frecuencia:.0f}MHz"
            grafica_3d(AZ, EL, G, frecuencia, ruta_salida / f"{base}_01_3D")
            for phi in (0, 90):
                theta, ganancia = extraer_corte(AZ, EL, G, phi)
                M = calcular_metricas(theta, ganancia)
                grafica_cartesiana(theta, ganancia, M, frecuencia, phi,
                                  ruta_salida / f"{base}_Phi{phi:02d}_02_Cartesiano")
                grafica_polar(theta, ganancia, M, frecuencia, phi,
                              ruta_salida / f"{base}_Phi{phi:02d}_03_Polar")
                registros.append({"Frecuencia_MHz": frecuencia, "Phi_grados": phi,
                                 "Ganancia_max_dBi": M.get("ganancia_max"),
                                 "HPBW_grados": M.get("HPBW"),
                                 "FNBW_grados": M.get("FNBW"),
                                 "SLL_dB": M.get("SLL")})
            procesados += 1
        except Exception as error:
            errores.append((archivo.name, str(error)))
            print("   [ERROR]", archivo.name, str(error))
    if not list(ruta_datos.glob("TransformedData_Gain_Abs_dBi_*MHz_SPM.xls")):
        raise FileNotFoundError(f"No hay archivos XLS 3D en {ruta_datos}")
    if registros:
        import csv
        with (ruta_salida / "RESUMEN_MEDICION_CORTES_3D.csv").open("w", newline="", encoding="utf-8-sig") as h:
            escritor = csv.DictWriter(h, fieldnames=list(registros[0]))
            escritor.writeheader()
            escritor.writerows(registros)
    if errores:
        (ruta_salida / "ERRORES_RADIACION_3D.txt").write_text(
            "\n".join(f"{nombre}: {e}" for nombre, e in errores), encoding="utf-8")
    print(f"   [3D] Frecuencias procesadas: {procesados}; errores: {len(errores)}")
    if procesados == 0:
        raise RuntimeError("No se pudo procesar XLS 3D. Revisa xlrd, scipy y los datos.")


# ==================================================================
# G. EJECUCIÓN INTEGRAL E INVENTARIO DE RESULTADOS
# ==================================================================

def _inventariar_figuras(raiz: Path) -> int:
    """Índice de archivos generado, separado por procedencia y tipo."""
    carpeta = raiz / "Resultados"
    elementos = []
    for png in sorted(carpeta.rglob("*.png")):
        ruta_rel = png.relative_to(raiz)
        partes = ruta_rel.parts
        pdf = png.with_suffix(".pdf")
        elementos.append({
            "Procedencia": partes[1] if len(partes) > 1 else "",
            "Grupo": partes[2] if len(partes) > 2 else "",
            "Figura_PNG": str(ruta_rel).replace("\\", "/"),
            "Figura_PDF": str(pdf.relative_to(raiz)).replace("\\", "/") if pdf.exists() else "",
            "Nombre": png.stem,
        })
    reportes = raiz / "Reportes"
    reportes.mkdir(exist_ok=True)
    destino = reportes / "INDICE_DE_FIGURAS.csv"
    with destino.open("w", newline="", encoding="utf-8-sig") as h:
        escritor = csv.DictWriter(h, fieldnames=["Procedencia", "Grupo", "Figura_PNG", "Figura_PDF", "Nombre"])
        escritor.writeheader()
        escritor.writerows(elementos)
    return len(elementos)


def main() -> int:
    analizador = argparse.ArgumentParser(
        description="Generación académica integral de gráficas HFSS y cámara anecoica."
    )
    analizador.add_argument("--raiz", type=Path, default=Path(__file__).resolve().parent,
                            help="Carpeta principal que contiene Datos y Resultados.")
    analizador.add_argument("--solo", choices=["todo", "hfss", "camara"], default="todo")
    analizador.add_argument("--f0", type=float, default=2.45, help="Frecuencia nominal (GHz).")
    analizador.add_argument("--dpi", type=int, default=None,
                            help="Resolución PNG. Sin este parámetro conserva la original (400/600).")
    analizador.add_argument("--sin-3d", action="store_true", help="No recalcular superficies 3D.")
    argumentos = analizador.parse_args()
    raiz = argumentos.raiz.resolve()
    datos = raiz / "Datos"
    salida = raiz / "Resultados"
    print("\n" + "=" * 65)
    print(" ANTENA MICROSTRIP 4x2 - FIGURAS PARA TESIS ")
    print("=" * 65)
    print("Raíz:", raiz)
    print("Modo:", argumentos.solo, "| Frecuencia:", argumentos.f0, "GHz")
    try:
        _verificar_dependencias(argumentos.solo)
    except Exception as exc:
        print("\n[ERROR]", str(exc), file=sys.stderr)
        return 2
    _organizar_nuevos_archivos(raiz)
    errores = []

    def ejecutar(etiqueta, funcion, *parametros):
        print("\n" + "-" * 65 + "\n" + etiqueta + "\n" + "-" * 65)
        try:
            funcion(*parametros)
        except Exception as exc:
            print("[ERROR]", etiqueta, type(exc).__name__, str(exc), file=sys.stderr)
            errores.append((etiqueta, type(exc).__name__, str(exc)))

    if argumentos.solo in ("todo", "hfss"):
        hfss = datos / "HFSS"
        ejecutar("HFSS - Principales", _graficar_hfss_principal,
                hfss, salida / "HFSS" / "01_Principales", argumentos.f0, argumentos.dpi)
        ejecutar("HFSS - Análisis adicionales", _graficar_hfss_adicional,
                hfss, salida / "HFSS" / "02_Adicionales", argumentos.f0, argumentos.dpi)

    if argumentos.solo in ("todo", "camara"):
        camara = datos / "Camara_Anecoica"
        ejecutar("Cámara anecoica - S11", _graficar_s11_experimental,
                camara / "S11" / "s11-sectorarray.csv", salida / "Camara_Anecoica" / "01_S11",
                argumentos.f0, argumentos.dpi)
        ejecutar("Cámara anecoica - Radiación 2D", _graficar_radiacion_2d_experimental,
                camara / "Radiacion_2D", salida / "Camara_Anecoica" / "02_Radiacion_2D",
                argumentos.f0, argumentos.dpi)
        if not argumentos.sin_3d:
            ejecutar("Cámara anecoica - Radiación 3D", _graficar_radiacion_3d_experimental,
                    camara / "Radiacion_3D", salida / "Camara_Anecoica" / "03_Radiacion_3D",
                    argumentos.f0, argumentos.dpi)

    numero = _inventariar_figuras(raiz)
    informe = [
        "INFORME DE EJECUCIÓN - FIGURAS HFSS Y CÁMARA ANECOICA",
        f"Modo: {argumentos.solo}", f"Frecuencia nominal: {argumentos.f0:.4f} GHz",
        f"PNG inventariados: {numero}",
        f"Incidencias: {len(errores)}",
    ]
    informe.extend(" | ".join(error) for error in errores)
    (raiz / "Reportes" / "INFORME_EJECUCION.txt").write_text("\n".join(informe)+"\n", encoding="utf-8")
    print("\n" + "=" * 65)
    print("FIN. Figuras PNG inventariadas:", numero)
    print("Índice:", raiz / "Reportes" / "INDICE_DE_FIGURAS.csv")
    if errores:
        print("Advertencia: se registraron", len(errores), "incidencias. Revisa Reportes/INFORME_EJECUCION.txt")
        return 1
    print("Ejecución terminada sin incidencias.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
